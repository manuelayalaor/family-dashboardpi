import type { KeyboardEvent, ReactNode } from "react";

interface CasitaCardProps {
  title: string;
  wallColor: string;
  wide?: boolean;
  headerRight?: ReactNode;
  onClick?: () => void;
  children: ReactNode;
}

/**
 * Every feature/service in the plaza (Tasks, Grocery, Messages, Photos,
 * AdGuard) renders through this. It's a full house facade — same cornice,
 * wrought-iron rail, shuttered windows, and arched door as the family
 * houses (reusing those exact classes, not a re-styled duplicate) — with
 * the widget's actual content floating in a paper-colored panel in front
 * of it, like a sign table set up at the door, rather than the content
 * being carved into the building itself.
 */
export function CasitaCard({ title, wallColor, wide, headerRight, onClick, children }: CasitaCardProps) {
  function handleKeyDown(e: KeyboardEvent<HTMLDivElement>) {
    if (!onClick) return;
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      onClick();
    }
  }

  return (
    <div
      className={`casita-card ${wide ? "casita-card--wide" : ""} ${onClick ? "casita-card--clickable" : ""}`}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onClick={onClick}
      onKeyDown={handleKeyDown}
    >
      <div className="casita-card__house" style={{ background: wallColor }}>
        <div className="house__cornice" />
        <div className="house__balcony-rail" />
        <span className="house__windows">
          <span className="house__shutter-window">
            <span className="house__shutter" />
            <span className="house__glass" />
            <span className="house__shutter" />
          </span>
          <span className="house__shutter-window">
            <span className="house__shutter" />
            <span className="house__glass" />
            <span className="house__shutter" />
          </span>
        </span>
        <div className="house__door">
          <div className="house__door-inner" />
        </div>
      </div>

      <div className="casita-card__panel">
        <div className="casita-card__panel-title">
          <span className="casita-card__title">{title}</span>
          {headerRight}
        </div>
        {children}
      </div>
    </div>
  );
}

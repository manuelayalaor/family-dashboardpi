import type { Person } from "../api/types";

interface HouseRowProps {
  people: Person[];
  selectedPersonId: number | null;
  onSelect: (personId: number | null) => void;
}

export function HouseRow({ people, selectedPersonId, onSelect }: HouseRowProps) {
  return (
    <section className="card house-row" aria-label="Family houses">
      <h2 className="house-row__title">The Neighborhood</h2>
      {people.length === 0 ? (
        <p className="empty-state">No houses yet — add your family in Admin.</p>
      ) : (
        <div className="house-row__grid">
          {people.map((person) => {
            const isSelected = selectedPersonId === person.id;
            return (
              <button
                key={person.id}
                type="button"
                className="house"
                aria-pressed={isSelected}
                onClick={() => onSelect(isSelected ? null : person.id)}
              >
                <span className="house__building">
                  <span className="house__roof" />
                  <span className="house__facade" style={{ background: person.house_color }}>
                    <span className="house__window" />
                    <span className="house__door" />
                    <span className="house__window" />
                  </span>
                  <span className="house__badge" aria-hidden>
                    {person.emoji}
                  </span>
                </span>
                <span className="house__name">{person.name}</span>
              </button>
            );
          })}
        </div>
      )}
    </section>
  );
}

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.events import Event
from app.models.people import Person

router = APIRouter(tags=["dashboard"])


@router.get("/health")
def health():
    """Liveness probe for docker-compose healthcheck and the kiosk splash screen."""
    return {"status": "ok"}


class TodayOut(BaseModel):
    date: str
    people_count: int
    event_count: int


@router.get("/dashboard/today", response_model=TodayOut)
def today_summary(db: Session = Depends(get_db)):
    """
    Small aggregate used to paint house notification dots ('has something
    today') without the frontend fetching and filtering the full event list
    itself. The full per-person event list still comes from /api/events.
    """
    now = datetime.now(timezone.utc)
    start_of_day = now.replace(hour=0, minute=0, second=0, microsecond=0)
    end_of_day = start_of_day + timedelta(days=1)

    event_count = len(
        db.scalars(
            select(Event.id).where(Event.start_time >= start_of_day, Event.start_time < end_of_day)
        ).all()
    )
    people_count = len(db.scalars(select(Person.id)).all())

    return TodayOut(date=start_of_day.date().isoformat(), people_count=people_count, event_count=event_count)

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.api import adguard, calendar, casita, dashboard, photos, tasks
from app.config import get_settings
from app.database import init_db

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(title=settings.app_name, lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,  # required for the Secret Casita session cookie
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(dashboard.router, prefix="/api")
app.include_router(calendar.router, prefix="/api")
app.include_router(tasks.router, prefix="/api")
app.include_router(photos.router, prefix="/api")
app.include_router(casita.router, prefix="/api")
app.include_router(adguard.router, prefix="/api")

# Original + thumbnail photo files are served directly by FastAPI here in
# development. In production, nginx intercepts /media/* and serves these
# files itself (see nginx/nginx.conf) so uvicorn isn't copying image bytes
# through Python on every slideshow tick.
settings.ensure_directories()
app.mount("/media/photos/originals", StaticFiles(directory=settings.photo_originals_dir), name="photo-originals")
app.mount("/media/photos/thumbnails", StaticFiles(directory=settings.photo_thumbnails_dir), name="photo-thumbnails")

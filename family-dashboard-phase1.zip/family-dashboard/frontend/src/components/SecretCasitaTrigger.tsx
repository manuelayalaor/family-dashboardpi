import type { Route } from "../lib/router";
import { MiniCasita } from "./MiniCasita";

interface SecretCasitaTriggerProps {
  navigate: (path: Route) => void;
}

/**
 * The brief calls for a hidden/private casita, PIN-gated (Phase 5 builds
 * the actual lock screen and feed). The whole point is that it shouldn't
 * announce itself: no title text, no "coming soon" subtitle, no card
 * background/border/shadow like its neighbors — just a small dark-walled
 * building sitting quietly in the corner of the plaza. Deliberately
 * excluded from any nav/menu; the only way to find it is to notice it.
 */
export function SecretCasitaTrigger({ navigate }: SecretCasitaTriggerProps) {
  return (
    <button
      type="button"
      className="secret-casita-trigger"
      onClick={() => navigate("/secret")}
      aria-label="A quiet corner of the plaza"
    >
      <MiniCasita wallColor="var(--color-ink)" />
    </button>
  );
}

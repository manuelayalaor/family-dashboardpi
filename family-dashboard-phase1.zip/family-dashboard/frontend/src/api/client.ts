import type {
  AdguardStatus,
  CalendarEvent,
  FamilyMessage,
  GroceryItem,
  Person,
  Task,
  TodaySummary,
  WeatherStatus,
} from "./types";

// Same-origin in production (nginx proxies /api to FastAPI). In `npm run
// dev`, Vite's own dev-server proxy (see vite.config.ts) forwards this to
// the backend, so this can stay a plain relative path in both cases.
const API_BASE = "/api";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: "include",
    headers: init?.body ? { "Content-Type": "application/json" } : undefined,
    ...init,
  });
  if (!res.ok) {
    throw new Error(`${path} failed: ${res.status} ${res.statusText}`);
  }
  if (res.status === 204) {
    return undefined as T;
  }
  return res.json() as Promise<T>;
}

export const api = {
  getPeople: () => request<Person[]>("/people"),

  getEvents: (params: { start?: string; end?: string; personId?: number } = {}) => {
    const search = new URLSearchParams();
    if (params.start) search.set("start", params.start);
    if (params.end) search.set("end", params.end);
    if (params.personId != null) search.set("person_id", String(params.personId));
    const qs = search.toString();
    return request<CalendarEvent[]>(`/events${qs ? `?${qs}` : ""}`);
  },

  getToday: () => request<TodaySummary>("/dashboard/today"),

  getAdguardStatus: () => request<AdguardStatus>("/adguard/status"),

  getWeather: () => request<WeatherStatus>("/weather"),

  // --- Tasks ---
  getTasks: () => request<Task[]>("/tasks"),
  createTask: (input: { title: string; assigned_person_id?: number | null }) =>
    request<Task>("/tasks", { method: "POST", body: JSON.stringify(input) }),
  updateTask: (id: number, input: Partial<Pick<Task, "title" | "assigned_person_id" | "is_complete">>) =>
    request<Task>(`/tasks/${id}`, { method: "PATCH", body: JSON.stringify(input) }),
  deleteTask: (id: number) => request<void>(`/tasks/${id}`, { method: "DELETE" }),

  // --- Grocery ---
  getGroceryItems: () => request<GroceryItem[]>("/grocery"),
  createGroceryItem: (input: { name: string; quantity?: string | null }) =>
    request<GroceryItem>("/grocery", { method: "POST", body: JSON.stringify(input) }),
  updateGroceryItem: (id: number, input: Partial<Pick<GroceryItem, "name" | "quantity" | "is_complete">>) =>
    request<GroceryItem>(`/grocery/${id}`, { method: "PATCH", body: JSON.stringify(input) }),
  deleteGroceryItem: (id: number) => request<void>(`/grocery/${id}`, { method: "DELETE" }),

  // --- Messages ---
  getMessages: () => request<FamilyMessage[]>("/messages"),
  createMessage: (input: { text: string }) =>
    request<FamilyMessage>("/messages", { method: "POST", body: JSON.stringify(input) }),
  deleteMessage: (id: number) => request<void>(`/messages/${id}`, { method: "DELETE" }),
};

import { useEffect, useMemo, useState } from "react";
import { api } from "../api/client";
import type { CalendarEvent, Person } from "../api/types";
import { getMonthMatrix, isSameDay, startOfDay, toLocalIso } from "../lib/datetime";

const WEEKDAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

interface EventFormState {
  editingId: number | null;
  title: string;
  time: string; // "HH:mm"
  allDay: boolean;
  personId: string;
}

const EMPTY_FORM: EventFormState = { editingId: null, title: "", time: "09:00", allDay: false, personId: "" };

export function CalendarView() {
  const today = useMemo(() => startOfDay(new Date()), []);
  const [monthCursor, setMonthCursor] = useState(() => new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDate, setSelectedDate] = useState(today);
  const [people, setPeople] = useState<Person[]>([]);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [selectedPersonId, setSelectedPersonId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<EventFormState>(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);

  const matrix = useMemo(
    () => getMonthMatrix(monthCursor.getFullYear(), monthCursor.getMonth()),
    [monthCursor],
  );

  useEffect(() => {
    api.getPeople().then(setPeople);
  }, []);

  useEffect(() => {
    setLoading(true);
    const gridStart = matrix[0][0].date;
    const gridEnd = matrix[matrix.length - 1][6].date;
    const end = new Date(gridEnd);
    end.setDate(end.getDate() + 1);
    api
      .getEvents({ start: toLocalIso(gridStart), end: toLocalIso(end) })
      .then(setEvents)
      .finally(() => setLoading(false));
  }, [matrix]);

  const eventsByDay = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const event of events) {
      if (selectedPersonId != null && event.person_id !== selectedPersonId) continue;
      const key = new Date(event.start_time).toDateString();
      const list = map.get(key) ?? [];
      list.push(event);
      map.set(key, list);
    }
    return map;
  }, [events, selectedPersonId]);

  const selectedDayEvents = (eventsByDay.get(selectedDate.toDateString()) ?? []).sort((a, b) =>
    a.start_time.localeCompare(b.start_time),
  );

  const peopleById = new Map(people.map((p) => [p.id, p]));
  const colorFor = (event: CalendarEvent) =>
    event.color ?? (event.person_id != null ? peopleById.get(event.person_id)?.house_color : null) ?? "#C1522A";

  function goToMonth(delta: number) {
    setMonthCursor((prev) => new Date(prev.getFullYear(), prev.getMonth() + delta, 1));
  }

  function goToToday() {
    setMonthCursor(new Date(today.getFullYear(), today.getMonth(), 1));
    setSelectedDate(today);
  }

  function startEdit(event: CalendarEvent) {
    const start = new Date(event.start_time);
    setForm({
      editingId: event.id,
      title: event.title,
      time: event.all_day
        ? "09:00"
        : `${String(start.getHours()).padStart(2, "0")}:${String(start.getMinutes()).padStart(2, "0")}`,
      allDay: event.all_day,
      personId: event.person_id != null ? String(event.person_id) : "",
    });
  }

  async function handleDelete(id: number) {
    setEvents((prev) => prev.filter((e) => e.id !== id));
    await api.deleteEvent(id);
    if (form.editingId === id) setForm(EMPTY_FORM);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const title = form.title.trim();
    if (!title || submitting) return;
    setSubmitting(true);
    try {
      const [hours, minutes] = form.time.split(":").map(Number);
      const startTime = new Date(selectedDate);
      startTime.setHours(hours || 0, minutes || 0, 0, 0);

      const payload = {
        title,
        start_time: toLocalIso(startTime),
        all_day: form.allDay,
        person_id: form.personId ? Number(form.personId) : null,
      };

      if (form.editingId != null) {
        const updated = await api.updateEvent(form.editingId, payload);
        setEvents((prev) => prev.map((ev) => (ev.id === updated.id ? updated : ev)));
      } else {
        const created = await api.createEvent(payload);
        setEvents((prev) => [...prev, created]);
      }
      setForm(EMPTY_FORM);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="calendar-view">
      <div className="card calendar-view__panel calendar-view__month">
        <div className="calendar-view__toolbar">
          <button type="button" className="calendar-view__nav" onClick={() => goToMonth(-1)} aria-label="Previous month">
            ‹
          </button>
          <h2 className="calendar-view__title">
            {monthCursor.toLocaleDateString([], { month: "long", year: "numeric" })}
          </h2>
          <button type="button" className="calendar-view__nav" onClick={() => goToMonth(1)} aria-label="Next month">
            ›
          </button>
          <button type="button" className="calendar-view__today-btn" onClick={goToToday}>
            Today
          </button>
        </div>

        {people.length > 0 && (
          <div className="calendar-view__filter">
            <button
              type="button"
              className={`calendar-view__filter-chip ${selectedPersonId == null ? "calendar-view__filter-chip--active" : ""}`}
              onClick={() => setSelectedPersonId(null)}
            >
              Everyone
            </button>
            {people.map((p) => (
              <button
                key={p.id}
                type="button"
                className={`calendar-view__filter-chip ${selectedPersonId === p.id ? "calendar-view__filter-chip--active" : ""}`}
                onClick={() => setSelectedPersonId(p.id)}
                style={selectedPersonId === p.id ? { background: p.house_color, color: "white" } : undefined}
              >
                {p.emoji} {p.name}
              </button>
            ))}
          </div>
        )}

        <div className="month-grid">
          {WEEKDAY_LABELS.map((label) => (
            <div key={label} className="month-grid__weekday">
              {label}
            </div>
          ))}
          {matrix.flat().map((cell) => {
            const dayEvents = eventsByDay.get(cell.date.toDateString()) ?? [];
            const isSelected = isSameDay(cell.date, selectedDate);
            const isToday = isSameDay(cell.date, today);
            return (
              <button
                key={cell.date.toISOString()}
                type="button"
                className={[
                  "month-grid__cell",
                  !cell.inCurrentMonth && "month-grid__cell--outside",
                  isSelected && "month-grid__cell--selected",
                  isToday && "month-grid__cell--today",
                ]
                  .filter(Boolean)
                  .join(" ")}
                onClick={() => {
                  setSelectedDate(cell.date);
                  setForm(EMPTY_FORM);
                }}
              >
                <span className="month-grid__day-number">{cell.date.getDate()}</span>
                <span className="month-grid__dots">
                  {dayEvents.slice(0, 4).map((event) => (
                    <span key={event.id} className="month-grid__dot" style={{ background: colorFor(event) }} />
                  ))}
                </span>
              </button>
            );
          })}
        </div>
        {loading && <p className="empty-state">Loading events…</p>}
      </div>

      <div className="card calendar-view__panel calendar-view__agenda">
        <h2 className="calendar-view__agenda-title">
          {selectedDate.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })}
        </h2>

        {selectedDayEvents.length === 0 ? (
          <p className="empty-state">Nothing scheduled.</p>
        ) : (
          <ul className="event-list">
            {selectedDayEvents.map((event) => (
              <li key={event.id} className="event-row">
                <span className="event-row__swatch" style={{ background: colorFor(event) }} />
                <span className="event-row__time">
                  {event.all_day
                    ? "All day"
                    : new Date(event.start_time).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
                </span>
                <span className="event-row__title">{event.title}</span>
                <button
                  type="button"
                  className="widget-row__delete"
                  aria-label={`Edit "${event.title}"`}
                  onClick={() => startEdit(event)}
                >
                  ✎
                </button>
                <button
                  type="button"
                  className="widget-row__delete"
                  aria-label={`Delete "${event.title}"`}
                  onClick={() => handleDelete(event.id)}
                >
                  ✕
                </button>
              </li>
            ))}
          </ul>
        )}

        <form className="event-form" onSubmit={handleSubmit}>
          <span className="event-form__label">{form.editingId != null ? "Edit event" : "Add event"}</span>
          <input
            type="text"
            className="widget-add__input"
            placeholder="Event title…"
            value={form.title}
            onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
            maxLength={200}
          />
          <div className="event-form__row">
            <input
              type="time"
              className="widget-add__input"
              value={form.time}
              disabled={form.allDay}
              onChange={(e) => setForm((f) => ({ ...f, time: e.target.value }))}
            />
            <label className="event-form__checkbox">
              <input
                type="checkbox"
                checked={form.allDay}
                onChange={(e) => setForm((f) => ({ ...f, allDay: e.target.checked }))}
              />
              All day
            </label>
          </div>
          {people.length > 0 && (
            <select
              className="widget-add__input"
              value={form.personId}
              onChange={(e) => setForm((f) => ({ ...f, personId: e.target.value }))}
              aria-label="Whose event"
            >
              <option value="">Whole family</option>
              {people.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.emoji} {p.name}
                </option>
              ))}
            </select>
          )}
          <div className="event-form__row">
            <button type="submit" className="widget-add__button" disabled={!form.title.trim() || submitting}>
              {form.editingId != null ? "Save" : "Add"}
            </button>
            {form.editingId != null && (
              <button type="button" className="calendar-view__cancel" onClick={() => setForm(EMPTY_FORM)}>
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

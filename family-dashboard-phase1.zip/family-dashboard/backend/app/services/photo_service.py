"""
Photo Casita business logic (uploads, thumbnailing, album management).

Deliberately left as a stub for Phase 1 — the foundation phase only needs
the directory layout (see config.photos_dir) and the Photo/Album tables to
exist so later phases don't need a migration. Implement in Phase 4:

  - save_upload(file) -> Photo: stream to photo_originals_dir with a safe
    generated filename (never trust the client-supplied name), generate a
    thumbnail with Pillow into photo_thumbnails_dir, insert a Photo row.
  - delete_photo(photo_id): remove both files, then the row.
  - reorder(photo_ids: list[int]): bulk-update sort_order.

Keep thumbnails small (e.g. 480px longest edge) — this runs on a Pi Zero 2 W
serving a slideshow to a TV, not full-resolution originals.
"""

"""
Weather lookup via Open-Meteo (https://open-meteo.com), chosen specifically
because it needs no API key and no account -- one less credential to manage
on an appliance that's meant to run unattended, and no signup step blocking
Phase 2 from being usable out of the box.

Entirely opt-in: if weather_latitude/weather_longitude aren't set in
config, get_current_weather() returns configured=False and the frontend
simply doesn't render the weather pill. This is the one place in the
project that calls out to the public internet for *dashboard* content
(rather than build tooling), which is why it's deliberately small, cached,
and disabled unless explicitly turned on.
"""
import time

import httpx

from app.config import get_settings

settings = get_settings()

_CACHE_TTL_SECONDS = 600  # 10 minutes -- weather doesn't need to be fresher than that
_cache: dict[str, object] = {"expires_at": 0.0, "payload": None}

# Open-Meteo WMO weather codes collapsed into the handful of buckets the
# frontend has icons for. See https://open-meteo.com/en/docs for the full table.
_CODE_TO_CONDITION: dict[int, str] = {
    0: "clear",
    1: "clear",
    2: "partly-cloudy",
    3: "cloudy",
    45: "fog",
    48: "fog",
    51: "drizzle",
    53: "drizzle",
    55: "drizzle",
    56: "drizzle",
    57: "drizzle",
    61: "rain",
    63: "rain",
    65: "rain",
    66: "rain",
    67: "rain",
    71: "snow",
    73: "snow",
    75: "snow",
    77: "snow",
    80: "rain",
    81: "rain",
    82: "rain",
    85: "snow",
    86: "snow",
    95: "storm",
    96: "storm",
    99: "storm",
}


def _condition_for(code: int, is_day: bool) -> str:
    condition = _CODE_TO_CONDITION.get(code, "cloudy")
    if condition == "clear" and not is_day:
        return "clear-night"
    return condition


async def get_current_weather() -> dict:
    if settings.weather_latitude is None or settings.weather_longitude is None:
        return {"configured": False, "temperature_c": None, "condition": None}

    now = time.time()
    if _cache["expires_at"] > now and _cache["payload"] is not None:
        return _cache["payload"]  # type: ignore[return-value]

    params = {
        "latitude": settings.weather_latitude,
        "longitude": settings.weather_longitude,
        "current": "temperature_2m,weather_code,is_day",
        "timezone": "auto",
    }
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get("https://api.open-meteo.com/v1/forecast", params=params)
            response.raise_for_status()
            data = response.json()
    except (httpx.HTTPError, ValueError):
        # A flaky/offline upstream shouldn't take the whole dashboard down --
        # just hide the weather pill until the next successful poll.
        return {"configured": True, "temperature_c": None, "condition": None}

    current = data.get("current", {})
    payload = {
        "configured": True,
        "temperature_c": current.get("temperature_2m"),
        "condition": _condition_for(int(current.get("weather_code", 3)), bool(current.get("is_day", 1))),
    }

    _cache["payload"] = payload
    _cache["expires_at"] = now + _CACHE_TTL_SECONDS
    return payload

import { useEffect, useState } from "react";

export type DayPhase = "morning" | "day" | "sunset" | "night";

/**
 * Buckets the current local hour into one of the four neighborhood phases
 * described in the project brief. Phase 1 only uses this to pick a subtle
 * background gradient; Phase 2 hooks the same value up to the full
 * sky/window/shadow treatment for the houses and plaza.
 */
export function phaseForHour(hour: number): DayPhase {
  if (hour >= 5 && hour < 9) return "morning";
  if (hour >= 9 && hour < 18) return "day";
  if (hour >= 18 && hour < 20) return "sunset";
  return "night";
}

export function useDayPhase(): DayPhase {
  const [phase, setPhase] = useState<DayPhase>(() => phaseForHour(new Date().getHours()));

  useEffect(() => {
    const id = window.setInterval(() => {
      setPhase(phaseForHour(new Date().getHours()));
    }, 60_000);
    return () => window.clearInterval(id);
  }, []);

  return phase;
}

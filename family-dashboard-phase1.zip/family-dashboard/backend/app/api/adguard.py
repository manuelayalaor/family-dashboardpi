"""
AdGuard Casita.

Phase 1 returns a static 'unconfigured' shape so the frontend can build the
widget UI against a stable contract before Phase 6 wires up
services/adguard_service.py against the real AdGuard Home API.
"""
from fastapi import APIRouter

router = APIRouter(tags=["adguard"])


@router.get("/adguard/status")
def adguard_status():
    return {"configured": False, "online": None}


@router.get("/adguard/stats")
def adguard_stats():
    return {
        "configured": False,
        "requests_today": 0,
        "blocked_today": 0,
        "block_rate": 0.0,
        "top_blocked_domains": [],
    }

import type { KeyboardEvent, ReactNode } from "react";

interface CasitaCardProps {
  title: string;
  wallColor: string;
  wide?: boolean;
  headerRight?: ReactNode;
  onClick?: () => void;
  children: ReactNode;
}

/**
 * Every feature/service in the plaza (Tasks, Grocery, Messages, Photos,
 * AdGuard) renders through this, so the plaza reads as a row of small
 * buildings — same roof-and-wall language as the family houses in "The
 * Neighborhood" — rather than generic cards with a decorative icon glued
 * in the corner.
 */
export function CasitaCard({ title, wallColor, wide, headerRight, onClick, children }: CasitaCardProps) {
  function handleKeyDown(e: KeyboardEvent<HTMLDivElement>) {
    if (!onClick) return;
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      onClick();
    }
  }

  return (
    <div
      className={`card casita-card ${wide ? "casita-card--wide" : ""} ${onClick ? "casita-card--clickable" : ""}`}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onClick={onClick}
      onKeyDown={handleKeyDown}
    >
      <div className="casita-card__roof" />
      <div className="casita-card__wall" style={{ background: wallColor }}>
        <span className="casita-card__title">{title}</span>
        {headerRight}
      </div>
      <div className="casita-card__body">{children}</div>
    </div>
  );
}

import type { AdguardStatus } from "../api/types";
import type { Route } from "../lib/router";
import { GroceryCard } from "./GroceryCard";
import { MessagesCard } from "./MessagesCard";
import { MiniCasita } from "./MiniCasita";
import { PhotoOverviewCard } from "./PhotoOverviewCard";
import { TasksOverviewCard } from "./TasksOverviewCard";

interface CasitaGridProps {
  adguardStatus: AdguardStatus | null;
  navigate: (path: Route) => void;
}

function AdguardSubtitle({ status }: { status: AdguardStatus | null }) {
  if (!status || !status.configured) {
    return <span className="casita-card__subtitle">Not connected yet</span>;
  }
  if (status.online) {
    return (
      <span className="casita-card__subtitle">
        <span className="status-dot status-dot--ok" />
        Protected
      </span>
    );
  }
  return (
    <span className="casita-card__subtitle">
      <span className="status-dot status-dot--down" />
      Offline
    </span>
  );
}

export function CasitaGrid({ adguardStatus, navigate }: CasitaGridProps) {
  return (
    <section className="card plaza" aria-label="More around the plaza">
      <div className="plaza__header">
        <h2 className="plaza__title">🌺 La Plaza</h2>
      </div>
      <div className="casita-grid">
        <PhotoOverviewCard navigate={navigate} />

        <div className="card casita-card">
          <div className="casita-card__header">
            <MiniCasita icon="🔐" wallColor="var(--color-ink)" />
            <span className="casita-card__title">La Casita Secreta</span>
          </div>
          <span className="casita-card__subtitle">Coming in Phase 5</span>
        </div>

        <div className="card casita-card">
          <div className="casita-card__header">
            <MiniCasita icon="🛡️" wallColor="var(--color-azure)" />
            <span className="casita-card__title">AdGuard</span>
          </div>
          <AdguardSubtitle status={adguardStatus} />
        </div>

        <GroceryCard />
        <MessagesCard />
        <TasksOverviewCard navigate={navigate} />
      </div>
    </section>
  );
}

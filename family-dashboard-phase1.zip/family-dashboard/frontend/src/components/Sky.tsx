import { useMemo } from "react";
import { generateStars } from "../lib/stars";

/**
 * Purely decorative — sits absolutely positioned behind the header (see
 * .sky-scene in global.css) and reads its look entirely from the
 * --celestial-*, --star-opacity, --cloud-opacity custom properties set on
 * [data-phase] in global.css. This component only has to exist once; the
 * phase change and all the crossfading/gliding is CSS transitions, so
 * there's nothing for the Pi to compute per frame.
 */
export function Sky() {
  const stars = useMemo(() => generateStars(45), []);

  return (
    <div className="sky-scene" aria-hidden="true">
      <div className="sky-scene__stars">
        {stars.map((star) => (
          <span
            key={star.id}
            className="star"
            style={{
              top: `${star.top}%`,
              left: `${star.left}%`,
              // @ts-expect-error custom properties aren't in React's CSSProperties type
              "--star-size": `${star.size}px`,
              "--star-duration": `${star.duration}s`,
              "--star-delay": `${star.delay}s`,
            }}
          />
        ))}
      </div>
      <div className="sky-scene__cloud sky-scene__cloud--a" />
      <div className="sky-scene__cloud sky-scene__cloud--b" />
      <div className="sky-scene__celestial" />
      <div className="sky-scene__ground-glow" />
    </div>
  );
}

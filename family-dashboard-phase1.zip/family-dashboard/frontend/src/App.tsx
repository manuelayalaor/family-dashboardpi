import { useEffect, useState } from "react";
import { api } from "./api/client";
import type { WeatherStatus } from "./api/types";
import { AdminConsole } from "./components/AdminConsole";
import { CalendarView } from "./components/CalendarView";
import { Dashboard } from "./components/Dashboard";
import { Layout } from "./components/Layout";
import { PhotosPage } from "./components/PhotosPage";
import { SecretCasitaPage } from "./components/SecretCasitaPage";
import { TaskBoard } from "./components/TaskBoard";
import { useDayPhase } from "./hooks/useDayPhase";
import { useRoute } from "./lib/router";

export default function App() {
  const phase = useDayPhase();
  const [route, navigate] = useRoute();
  const [weather, setWeather] = useState<WeatherStatus | null>(null);

  useEffect(() => {
    api.getWeather().then(setWeather).catch(() => undefined);
  }, []);

  return (
    <Layout phase={phase} weather={weather} route={route} navigate={navigate}>
      {route === "/" && <Dashboard navigate={navigate} />}
      {route === "/calendar" && <CalendarView />}
      {route === "/tasks" && <TaskBoard />}
      {route === "/photos" && <PhotosPage />}
      {route === "/secret" && <SecretCasitaPage navigate={navigate} />}
      {route === "/admin" && <AdminConsole navigate={navigate} />}
    </Layout>
  );
}

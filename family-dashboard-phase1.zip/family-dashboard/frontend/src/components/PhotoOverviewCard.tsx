import { useEffect, useState } from "react";
import { api, photoThumbnailUrl } from "../api/client";
import type { Photo } from "../api/types";
import type { Route } from "../lib/router";
import { CasitaCard } from "./CasitaCard";

interface PhotoOverviewCardProps {
  navigate: (path: Route) => void;
}

const CYCLE_MS = 5000;

export function PhotoOverviewCard({ navigate }: PhotoOverviewCardProps) {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    api
      .getPhotos()
      .then(setPhotos)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (photos.length <= 1) return;
    const id = window.setInterval(() => setIndex((i) => (i + 1) % photos.length), CYCLE_MS);
    return () => window.clearInterval(id);
  }, [photos.length]);

  const current = photos[index];

  return (
    <CasitaCard
      title="Photo Casita"
      wallColor="var(--color-mustard)"
      wide
      onClick={() => navigate("/photos")}
      headerRight={photos.length > 0 ? <span className="widget-row__meta">{photos.length} photos</span> : undefined}
    >
      {loading ? (
        <span className="casita-card__subtitle">Loading…</span>
      ) : !current ? (
        <span className="casita-card__subtitle">No photos yet — upload some in Photos.</span>
      ) : (
        <div className="photo-overview__frame">
          <img
            key={current.id}
            className="photo-overview__cycling-image"
            src={photoThumbnailUrl(current.thumbnail_filename)}
            alt={current.caption ?? ""}
            loading="lazy"
          />
          {current.caption && <span className="photo-overview__caption">{current.caption}</span>}
        </div>
      )}
    </CasitaCard>
  );
}

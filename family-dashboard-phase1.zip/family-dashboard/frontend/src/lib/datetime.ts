export interface MonthCell {
  date: Date;
  inCurrentMonth: boolean;
}

/**
 * Builds a Sunday-first month grid, including the leading/trailing days
 * from adjacent months needed to fill complete weeks. Produces 4–6 rows
 * depending on how the month falls, rather than always padding to 6.
 */
export function getMonthMatrix(year: number, month: number): MonthCell[][] {
  const firstOfMonth = new Date(year, month, 1);
  const startOffset = firstOfMonth.getDay(); // 0 = Sunday
  const cursor = new Date(year, month, 1 - startOffset);

  const weeks: MonthCell[][] = [];
  for (;;) {
    const row: MonthCell[] = [];
    for (let day = 0; day < 7; day++) {
      row.push({ date: new Date(cursor), inCurrentMonth: cursor.getMonth() === month });
      cursor.setDate(cursor.getDate() + 1);
    }
    weeks.push(row);
    if (cursor.getMonth() !== month) break; // next row would start in the following month
  }
  return weeks;
}

export function isSameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

export function startOfDay(date: Date): Date {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}

/**
 * Formats a Date as "YYYY-MM-DDTHH:mm:ss" using LOCAL wall-clock fields —
 * unlike Date.prototype.toISOString(), which always converts to UTC first.
 *
 * Event times are stored and queried as naive local timestamps (no
 * timezone offset) throughout this app: a single-location kiosk dashboard
 * has no need to reason about timezones at all, so keeping everything as
 * plain local wall-clock time avoids an entire category of off-by-one-day
 * bugs. Always use this (not toISOString()) when building a date to send
 * to the API.
 */
export function toLocalIso(date: Date): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return (
    `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}` +
    `T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
  );
}

/**
 * "Just now" / "5m ago" / "3h ago" / "2d ago" for the message feed.
 * Input is a naive local timestamp string from the backend (see
 * toLocalIso above for why there's no timezone conversion here either).
 */
export function relativeTime(isoLocal: string): string {
  const then = new Date(isoLocal).getTime();
  const diffSeconds = Math.max(0, Math.round((Date.now() - then) / 1000));
  if (diffSeconds < 60) return "just now";
  const diffMinutes = Math.round(diffSeconds / 60);
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  const diffHours = Math.round(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.round(diffHours / 24);
  return `${diffDays}d ago`;
}

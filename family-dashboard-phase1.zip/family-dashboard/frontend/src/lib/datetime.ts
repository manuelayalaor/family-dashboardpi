/**
 * Formats a Date as "YYYY-MM-DDTHH:mm:ss" using LOCAL wall-clock fields —
 * unlike Date.prototype.toISOString(), which always converts to UTC first.
 *
 * Event times are stored and queried as naive local timestamps (no
 * timezone offset) throughout this app: a single-location kiosk dashboard
 * has no need to reason about timezones at all, so keeping everything as
 * plain local wall-clock time avoids an entire category of off-by-one-day
 * bugs. Always use this (not toISOString()) when building a date to send
 * to the API.
 */
export function toLocalIso(date: Date): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return (
    `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}` +
    `T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
  );
}

/**
 * "Just now" / "5m ago" / "3h ago" / "2d ago" for the message feed.
 * Input is a naive local timestamp string from the backend (see
 * toLocalIso above for why there's no timezone conversion here either).
 */
export function relativeTime(isoLocal: string): string {
  const then = new Date(isoLocal).getTime();
  const diffSeconds = Math.max(0, Math.round((Date.now() - then) / 1000));
  if (diffSeconds < 60) return "just now";
  const diffMinutes = Math.round(diffSeconds / 60);
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  const diffHours = Math.round(diffMinutes / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.round(diffHours / 24);
  return `${diffDays}d ago`;
}

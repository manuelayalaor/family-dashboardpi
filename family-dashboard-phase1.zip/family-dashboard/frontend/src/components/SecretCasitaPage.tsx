import { useEffect, useState } from "react";
import { api } from "../api/client";
import type { CasitaPost } from "../api/types";
import { relativeTime } from "../lib/datetime";
import type { Route } from "../lib/router";

interface SecretCasitaPageProps {
  navigate: (path: Route) => void;
}

type Stage = "loading" | "setup" | "locked" | "unlocked";

export function SecretCasitaPage({ navigate }: SecretCasitaPageProps) {
  const [stage, setStage] = useState<Stage>("loading");
  const [pinInput, setPinInput] = useState("");
  const [confirmPinInput, setConfirmPinInput] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [posts, setPosts] = useState<CasitaPost[]>([]);
  const [newText, setNewText] = useState("");
  const [newLink, setNewLink] = useState("");
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    api
      .getCasitaStatus()
      .then(async (status) => {
        if (!status.pin_configured) {
          setStage("setup");
          return;
        }
        // A session cookie from an earlier visit might still be valid --
        // try the feed directly rather than always forcing PIN re-entry.
        try {
          const existingPosts = await api.getCasitaPosts();
          setPosts(existingPosts);
          setStage("unlocked");
        } catch {
          setStage("locked");
        }
      })
      .catch(() => setStage("locked"));
  }, []);

  async function handleSetup(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (pinInput.length < 4) {
      setError("PIN needs to be at least 4 digits.");
      return;
    }
    if (pinInput !== confirmPinInput) {
      setError("PINs don't match.");
      return;
    }
    setSubmitting(true);
    try {
      await api.casitaSetup(pinInput);
      const existingPosts = await api.getCasitaPosts();
      setPosts(existingPosts);
      setStage("unlocked");
    } catch {
      setError("Couldn't set up the PIN. Try again.");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await api.casitaLogin(pinInput);
      const existingPosts = await api.getCasitaPosts();
      setPosts(existingPosts);
      setStage("unlocked");
      setPinInput("");
    } catch {
      setError("Incorrect PIN.");
      setPinInput("");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleLock() {
    await api.casitaLogout();
    setStage("locked");
    setPosts([]);
  }

  async function handlePost(e: React.FormEvent) {
    e.preventDefault();
    const text = newText.trim();
    const link = newLink.trim();
    if (!text && !link) return;
    setPosting(true);
    try {
      const post = await api.createCasitaPost({ text: text || undefined, link_url: link || undefined });
      setPosts((prev) => [post, ...prev]);
      setNewText("");
      setNewLink("");
    } finally {
      setPosting(false);
    }
  }

  async function handleDeletePost(id: number) {
    setPosts((prev) => prev.filter((p) => p.id !== id));
    await api.deleteCasitaPost(id);
  }

  if (stage === "loading") {
    return <div className="card secret-casita-page" />;
  }

  if (stage === "setup" || stage === "locked") {
    return (
      <div className="card secret-casita-page">
        <span className="secret-casita-page__lock">🔒</span>
        {stage === "setup" ? (
          <>
            <h2 className="task-board-page__title">Set up La Casita Secreta</h2>
            <p className="secret-casita-page__text">
              Choose a PIN (4+ digits). Anyone with the PIN can read and post here — it isn't tied to a
              specific person.
            </p>
            <form className="secret-casita-page__form" onSubmit={handleSetup}>
              <input
                type="password"
                inputMode="numeric"
                className="widget-add__input"
                placeholder="New PIN"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ""))}
                maxLength={12}
              />
              <input
                type="password"
                inputMode="numeric"
                className="widget-add__input"
                placeholder="Confirm PIN"
                value={confirmPinInput}
                onChange={(e) => setConfirmPinInput(e.target.value.replace(/\D/g, ""))}
                maxLength={12}
              />
              {error && <p className="empty-state">{error}</p>}
              <button type="submit" className="widget-add__button" disabled={submitting}>
                {submitting ? "Setting up…" : "Set PIN"}
              </button>
            </form>
          </>
        ) : (
          <>
            <h2 className="task-board-page__title">La Casita Secreta</h2>
            <form className="secret-casita-page__form" onSubmit={handleLogin}>
              <input
                type="password"
                inputMode="numeric"
                autoFocus
                className="widget-add__input"
                placeholder="Enter PIN"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ""))}
                maxLength={12}
              />
              {error && <p className="empty-state">{error}</p>}
              <button type="submit" className="widget-add__button" disabled={submitting || pinInput.length < 4}>
                {submitting ? "Checking…" : "Unlock"}
              </button>
            </form>
            <p className="secret-casita-page__hint">Forgot it? It can be reset from Admin.</p>
          </>
        )}
        <button type="button" className="calendar-view__cancel" onClick={() => navigate("/")}>
          Back home
        </button>
      </div>
    );
  }

  return (
    <div className="card secret-casita-page secret-casita-page--unlocked">
      <div className="secret-casita-page__header">
        <h2 className="task-board-page__title">🔓 La Casita Secreta</h2>
        <button type="button" className="widget-add__button" onClick={handleLock}>
          Lock
        </button>
      </div>

      {posts.length === 0 ? (
        <p className="empty-state">Nothing here yet — send something to the family.</p>
      ) : (
        <ul className="casita-feed">
          {posts.map((post) => (
            <li key={post.id} className="casita-feed__post">
              {post.text && <p className="casita-feed__text">{post.text}</p>}
              {post.link_url &&
                (post.link_title ? (
                  <a href={post.link_url} target="_blank" rel="noreferrer" className="casita-feed__link-card">
                    {post.link_image_url && (
                      <img src={post.link_image_url} alt="" className="casita-feed__link-image" />
                    )}
                    <span className="casita-feed__link-body">
                      <span className="casita-feed__link-title">{post.link_title}</span>
                      {post.link_description && (
                        <span className="casita-feed__link-desc">{post.link_description}</span>
                      )}
                      <span className="casita-feed__link-site">{post.link_site_name ?? post.link_url}</span>
                    </span>
                  </a>
                ) : (
                  <a href={post.link_url} target="_blank" rel="noreferrer" className="casita-feed__link-fallback">
                    🔗 Open Link
                  </a>
                ))}
              <div className="casita-feed__footer">
                <span className="widget-row__meta">{relativeTime(post.created_at)}</span>
                <button
                  type="button"
                  className="widget-row__delete"
                  aria-label="Delete post"
                  onClick={() => handleDeletePost(post.id)}
                >
                  ✕
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <form className="event-form" onSubmit={handlePost}>
        <input
          type="text"
          className="widget-add__input"
          placeholder="Say something…"
          value={newText}
          onChange={(e) => setNewText(e.target.value)}
          maxLength={2000}
        />
        <input
          type="url"
          className="widget-add__input"
          placeholder="Paste a link (optional)…"
          value={newLink}
          onChange={(e) => setNewLink(e.target.value)}
        />
        <button
          type="submit"
          className="widget-add__button"
          disabled={posting || (!newText.trim() && !newLink.trim())}
        >
          {posting ? "Posting…" : "Post"}
        </button>
      </form>
    </div>
  );
}

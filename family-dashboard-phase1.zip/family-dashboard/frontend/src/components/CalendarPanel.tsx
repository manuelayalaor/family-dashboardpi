import type { CalendarEvent, Person } from "../api/types";

interface CalendarPanelProps {
  events: CalendarEvent[];
  people: Person[];
  selectedPersonId: number | null;
  loading: boolean;
}

function colorFor(event: CalendarEvent, peopleById: Map<number, Person>): string {
  if (event.color) return event.color;
  if (event.person_id != null) return peopleById.get(event.person_id)?.house_color ?? "#C1522A";
  return "#C1522A";
}

export function CalendarPanel({ events, people, selectedPersonId, loading }: CalendarPanelProps) {
  const peopleById = new Map(people.map((p) => [p.id, p]));
  const visibleEvents =
    selectedPersonId == null ? events : events.filter((e) => e.person_id === selectedPersonId);
  const sorted = [...visibleEvents].sort((a, b) => a.start_time.localeCompare(b.start_time));

  const focusedPerson = selectedPersonId != null ? peopleById.get(selectedPersonId) : null;

  return (
    <section className="card calendar-panel" aria-label="Today's schedule">
      <div className="calendar-panel__header">
        <h2>{focusedPerson ? `${focusedPerson.emoji} ${focusedPerson.name}'s Day` : "Today"}</h2>
        <span className="calendar-panel__today">
          {new Date().toLocaleDateString([], { month: "short", day: "numeric" })}
        </span>
      </div>

      {loading ? (
        <p className="empty-state">Loading the day's plans…</p>
      ) : sorted.length === 0 ? (
        <p className="empty-state">
          {focusedPerson ? `Nothing on ${focusedPerson.name}'s calendar today.` : "Nothing on the calendar today — enjoy it."}
        </p>
      ) : (
        <ul className="event-list">
          {sorted.map((event) => (
            <li key={event.id} className="event-row">
              <span className="event-row__swatch" style={{ background: colorFor(event, peopleById) }} />
              <span className="event-row__time">
                {event.all_day
                  ? "All day"
                  : new Date(event.start_time).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
              </span>
              <span className="event-row__title">{event.title}</span>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

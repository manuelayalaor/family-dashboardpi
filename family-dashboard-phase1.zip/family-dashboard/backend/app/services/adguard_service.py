"""
AdGuard Home API client, against the existing AdGuard Home instance
already running on the Pi. Connection details (address, username,
password) are admin-configurable at runtime via Settings, rather than
requiring a redeploy to change -- falling back to the static .env values
(DASHBOARD_ADGUARD_*) if nothing's been set through Admin, so an existing
.env-based setup keeps working untouched.

Uses HTTP Basic Auth. Both status and stats are cached briefly (30s)
rather than hit on every dashboard poll -- the Pi Zero 2 W is also
running AdGuard itself, so this stays polite about it.
"""
import time

import httpx
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models.settings import Setting, SettingKey

settings = get_settings()

_TIMEOUT = httpx.Timeout(4.0)
_CACHE_TTL_SECONDS = 30
_status_cache: dict[str, object] = {"expires_at": 0.0, "payload": None}
_stats_cache: dict[str, object] = {"expires_at": 0.0, "payload": None}


def _setting(db: Session, key: str) -> str | None:
    row = db.get(Setting, key)
    return row.value if row else None


def get_connection(db: Session) -> tuple[str | None, str | None, str | None]:
    """(base_url, username, password), preferring Admin-configured values over .env."""
    base_url = _setting(db, SettingKey.ADGUARD_BASE_URL) or settings.adguard_base_url
    username = _setting(db, SettingKey.ADGUARD_USERNAME) or settings.adguard_username
    password = _setting(db, SettingKey.ADGUARD_PASSWORD) or settings.adguard_password
    return base_url, username, password


async def get_status(db: Session) -> dict:
    base_url, username, password = get_connection(db)
    if not base_url:
        return {"configured": False, "online": None}

    now = time.time()
    if _status_cache["expires_at"] > now and _status_cache["payload"] is not None:
        return _status_cache["payload"]  # type: ignore[return-value]

    auth = (username, password) if username and password else None
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT, auth=auth) as client:
            response = await client.get(f"{base_url}/control/status")
            response.raise_for_status()
            data = response.json()
        payload = {"configured": True, "online": bool(data.get("protection_enabled", True))}
    except (httpx.HTTPError, ValueError):
        # AdGuard down/unreachable is a normal, expected state to show, not
        # a dashboard-breaking error -- surface it as offline, not a 500.
        payload = {"configured": True, "online": False}

    _status_cache["payload"] = payload
    _status_cache["expires_at"] = now + _CACHE_TTL_SECONDS
    return payload


async def get_stats(db: Session) -> dict:
    empty = {
        "configured": False,
        "requests_today": 0,
        "blocked_today": 0,
        "block_rate": 0.0,
        "top_blocked_domains": [],
    }
    base_url, username, password = get_connection(db)
    if not base_url:
        return empty

    now = time.time()
    if _stats_cache["expires_at"] > now and _stats_cache["payload"] is not None:
        return _stats_cache["payload"]  # type: ignore[return-value]

    auth = (username, password) if username and password else None
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT, auth=auth) as client:
            response = await client.get(f"{base_url}/control/stats")
            response.raise_for_status()
            data = response.json()
    except (httpx.HTTPError, ValueError):
        payload = {**empty, "configured": True}
        _stats_cache["payload"] = payload
        _stats_cache["expires_at"] = now + _CACHE_TTL_SECONDS
        return payload

    # AdGuard's /control/stats returns per-interval arrays (last N periods,
    # e.g. hourly buckets for a day); today's totals are the sum of those.
    requests_today = sum(data.get("dns_queries", []) or [0])
    blocked_today = sum(data.get("blocked_filtering", []) or [0])
    block_rate = round((blocked_today / requests_today) * 100, 1) if requests_today else 0.0

    top_domains = [
        {"domain": next(iter(entry)), "count": next(iter(entry.values()))}
        for entry in (data.get("top_blocked_domains") or [])[:5]
    ]

    payload = {
        "configured": True,
        "requests_today": requests_today,
        "blocked_today": blocked_today,
        "block_rate": block_rate,
        "top_blocked_domains": top_domains,
    }
    _stats_cache["payload"] = payload
    _stats_cache["expires_at"] = now + _CACHE_TTL_SECONDS
    return payload


def invalidate_cache() -> None:
    """Called after Admin changes the connection settings, so the next
    poll reflects the new address immediately instead of serving a cached
    result (possibly an "offline" one) from the old configuration."""
    _status_cache["expires_at"] = 0.0
    _stats_cache["expires_at"] = 0.0

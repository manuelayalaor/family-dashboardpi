import { useEffect, useState } from "react";
import { api } from "../api/client";
import type { AdguardStats } from "../api/types";
import type { Route } from "../lib/router";

interface AdGuardPageProps {
  navigate: (path: Route) => void;
}

export function AdGuardPage({ navigate }: AdGuardPageProps) {
  const [stats, setStats] = useState<AdguardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .getAdguardStats()
      .then(setStats)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="card task-board-page" />;
  }

  if (!stats?.configured) {
    return (
      <div className="card secret-casita-page">
        <span className="secret-casita-page__lock">🛡️</span>
        <h2 className="task-board-page__title">AdGuard isn't connected yet</h2>
        <p className="secret-casita-page__text">
          Set `DASHBOARD_ADGUARD_BASE_URL` (and username/password, if your instance needs them) in
          the Pi's `.env` file, then restart the dashboard.
        </p>
        <button type="button" className="widget-add__button" onClick={() => navigate("/")}>
          Back home
        </button>
      </div>
    );
  }

  return (
    <div className="card task-board-page">
      <h2 className="task-board-page__title">🛡️ AdGuard</h2>

      <div className="adguard-stats">
        <div className="adguard-stats__hero">
          <span className="adguard-stats__hero-label">Blocked Today</span>
          <span className="adguard-stats__hero-number">{stats.blocked_today.toLocaleString()}</span>
        </div>

        <div className="adguard-stats__row">
          <div className="adguard-stats__cell">
            <span className="adguard-stats__cell-label">Requests</span>
            <span className="adguard-stats__cell-number">{stats.requests_today.toLocaleString()}</span>
          </div>
          <div className="adguard-stats__cell">
            <span className="adguard-stats__cell-label">Blocked</span>
            <span className="adguard-stats__cell-number">{stats.blocked_today.toLocaleString()}</span>
          </div>
          <div className="adguard-stats__cell">
            <span className="adguard-stats__cell-label">Block rate</span>
            <span className="adguard-stats__cell-number">{stats.block_rate}%</span>
          </div>
        </div>

        {stats.top_blocked_domains.length > 0 && (
          <div className="adguard-stats__domains">
            <h3 className="adguard-stats__domains-title">Top Blocked Domains</h3>
            <ul className="widget-list">
              {stats.top_blocked_domains.map((entry) => (
                <li key={entry.domain} className="widget-row">
                  <span className="widget-row__label">{entry.domain}</span>
                  <span className="widget-row__meta">{entry.count.toLocaleString()}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}

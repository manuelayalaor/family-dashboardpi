import { useEffect, useRef, useState } from "react";
import { api } from "../api/client";
import type { Person, Task, TaskStatus } from "../api/types";

const COLUMNS: { status: TaskStatus; label: string }[] = [
  { status: "todo", label: "To Do" },
  { status: "in_progress", label: "In Progress" },
  { status: "done", label: "Done" },
];

const NEXT_STATUS: Record<TaskStatus, TaskStatus> = {
  todo: "in_progress",
  in_progress: "done",
  done: "todo",
};

interface DragState {
  id: number;
  x: number;
  y: number;
  offsetX: number;
  offsetY: number;
  width: number;
}

export function TaskBoard() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [people, setPeople] = useState<Person[]>([]);
  const [loading, setLoading] = useState(true);
  const [newTitle, setNewTitle] = useState("");
  const [newAssignee, setNewAssignee] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [drag, setDrag] = useState<DragState | null>(null);
  const [hoverStatus, setHoverStatus] = useState<TaskStatus | null>(null);
  const dragRef = useRef<DragState | null>(null);

  useEffect(() => {
    Promise.all([api.getTasks(), api.getPeople()])
      .then(([taskRes, peopleRes]) => {
        setTasks(taskRes);
        setPeople(peopleRes);
      })
      .finally(() => setLoading(false));
  }, []);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    const title = newTitle.trim();
    if (!title || submitting) return;
    setSubmitting(true);
    try {
      const task = await api.createTask({
        title,
        assigned_person_id: newAssignee ? Number(newAssignee) : null,
      });
      setTasks((prev) => [task, ...prev]);
      setNewTitle("");
      setNewAssignee("");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(id: number) {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    await api.deleteTask(id);
  }

  async function setStatus(id: number, status: TaskStatus) {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, status } : t)));
    await api.updateTask(id, { status });
  }

  function handlePointerDown(e: React.PointerEvent<HTMLDivElement>, task: Task) {
    if (e.button !== undefined && e.button !== 0) return; // left click / primary touch only
    const rect = e.currentTarget.getBoundingClientRect();
    const next: DragState = {
      id: task.id,
      x: e.clientX,
      y: e.clientY,
      offsetX: e.clientX - rect.left,
      offsetY: e.clientY - rect.top,
      width: rect.width,
    };
    dragRef.current = next;
    setDrag(next);
    e.currentTarget.setPointerCapture(e.pointerId);
  }

  function handlePointerMove(e: React.PointerEvent<HTMLDivElement>) {
    if (!dragRef.current) return;
    const next = { ...dragRef.current, x: e.clientX, y: e.clientY };
    dragRef.current = next;
    setDrag(next);

    const under = document.elementFromPoint(e.clientX, e.clientY);
    const column = under?.closest<HTMLElement>("[data-task-column]");
    setHoverStatus((column?.dataset.taskColumn as TaskStatus | undefined) ?? null);
  }

  async function handlePointerUp() {
    const current = dragRef.current;
    const targetStatus = hoverStatus;
    dragRef.current = null;
    setDrag(null);
    setHoverStatus(null);
    if (!current) return;
    const task = tasks.find((t) => t.id === current.id);
    if (task && targetStatus && targetStatus !== task.status) {
      await setStatus(current.id, targetStatus);
    }
  }

  const personFor = (id: number | null) => (id == null ? null : people.find((p) => p.id === id));

  return (
    <div className="card task-board-page">
      <h2 className="task-board-page__title">📝 Tasks</h2>

      {loading ? (
        <p className="empty-state">Loading…</p>
      ) : (
        <div className="task-board">
          {COLUMNS.map((col) => (
            <div
              key={col.status}
              className={`task-column ${hoverStatus === col.status && drag ? "task-column--hover" : ""}`}
              data-task-column={col.status}
            >
              <span className="task-column__title">{col.label}</span>
              <div className="task-column__list">
                {tasks
                  .filter((t) => t.status === col.status)
                  .map((task) => {
                    const assignee = personFor(task.assigned_person_id);
                    const isDragging = drag?.id === task.id;
                    return (
                      <div
                        key={task.id}
                        className={`task-card ${isDragging ? "task-card--dragging" : ""}`}
                        style={
                          isDragging && drag
                            ? {
                                position: "fixed",
                                left: drag.x - drag.offsetX,
                                top: drag.y - drag.offsetY,
                                width: drag.width,
                                zIndex: 1000,
                              }
                            : undefined
                        }
                        onPointerDown={(e) => handlePointerDown(e, task)}
                        onPointerMove={handlePointerMove}
                        onPointerUp={handlePointerUp}
                        onPointerCancel={handlePointerUp}
                      >
                        <span className="task-card__title">{task.title}</span>
                        <div className="task-card__footer">
                          {assignee && <span className="widget-row__meta">{assignee.emoji}</span>}
                          <button
                            type="button"
                            className="task-card__advance"
                            title={`Move to ${COLUMNS.find((c) => c.status === NEXT_STATUS[task.status])?.label}`}
                            aria-label={`Move "${task.title}" to next column`}
                            onPointerDown={(e) => e.stopPropagation()}
                            onClick={() => setStatus(task.id, NEXT_STATUS[task.status])}
                          >
                            ▶
                          </button>
                          <button
                            type="button"
                            className="widget-row__delete"
                            aria-label={`Delete "${task.title}"`}
                            onPointerDown={(e) => e.stopPropagation()}
                            onClick={() => handleDelete(task.id)}
                          >
                            ✕
                          </button>
                        </div>
                      </div>
                    );
                  })}
                {tasks.filter((t) => t.status === col.status).length === 0 && (
                  <span className="task-column__empty">—</span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <form className="widget-add" onSubmit={handleAdd}>
        <input
          type="text"
          className="widget-add__input"
          placeholder="Add a task…"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          maxLength={200}
        />
        {people.length > 0 && (
          <select
            className="widget-add__input"
            style={{ flex: "0 0 auto", width: "auto" }}
            value={newAssignee}
            onChange={(e) => setNewAssignee(e.target.value)}
            aria-label="Assign to"
          >
            <option value="">Unassigned</option>
            {people.map((p) => (
              <option key={p.id} value={p.id}>
                {p.emoji} {p.name}
              </option>
            ))}
          </select>
        )}
        <button type="submit" className="widget-add__button" disabled={!newTitle.trim() || submitting}>
          Add
        </button>
      </form>
    </div>
  );
}

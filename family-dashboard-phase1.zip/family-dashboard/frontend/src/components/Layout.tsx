import { useEffect, useState, type ReactNode } from "react";
import type { DayPhase } from "../hooks/useDayPhase";
import type { WeatherStatus } from "../api/types";
import { Sky } from "./Sky";

interface LayoutProps {
  phase: DayPhase;
  weather: WeatherStatus | null;
  children: ReactNode;
}

const PHASE_ICON: Record<DayPhase, string> = {
  morning: "🌅",
  day: "☀️",
  sunset: "🌇",
  night: "🌙",
};

const CONDITION_ICON: Record<string, string> = {
  clear: "☀️",
  "clear-night": "🌙",
  "partly-cloudy": "⛅",
  cloudy: "☁️",
  fog: "🌫️",
  drizzle: "🌦️",
  rain: "🌧️",
  storm: "⛈️",
  snow: "❄️",
};

export function Layout({ phase, weather, children }: LayoutProps) {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000 * 30);
    return () => window.clearInterval(id);
  }, []);

  const timeLabel = now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  const dateLabel = now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });

  return (
    <div className="app-shell" data-phase={phase}>
      <Sky />
      <header className="app-header">
        <h1 className="app-title">🏘️ La Familia</h1>
        <div className="app-clock">
          <span>{dateLabel}</span>
          <span>{timeLabel}</span>
          {weather?.configured && weather.temperature_c != null && (
            <span className="weather-pill">
              {CONDITION_ICON[weather.condition ?? ""] ?? "🌡️"} {Math.round(weather.temperature_c)}°
            </span>
          )}
          <span className="phase-pill">
            {PHASE_ICON[phase]} {phase}
          </span>
        </div>
      </header>
      <main className="app-main">{children}</main>
    </div>
  );
}

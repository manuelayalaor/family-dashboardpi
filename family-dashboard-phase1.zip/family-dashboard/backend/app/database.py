"""
Database engine and session management.

Uses plain synchronous SQLAlchemy rather than an async driver. On a Pi Zero 2 W
the request volume from a handful of family devices is tiny, so the extra
complexity of async SQLite (aiosqlite) buys nothing but adds overhead and
another moving part to keep working reliably unattended.
"""
from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import get_settings

settings = get_settings()
settings.ensure_directories()

# check_same_thread=False is required because FastAPI may service a single
# session's request in a worker thread different from the one that opened it.
engine = create_engine(
    settings.resolved_database_url,
    connect_args={"check_same_thread": False},
    echo=False,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that yields a request-scoped DB session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _column_names(table: str) -> list[str]:
    with engine.connect() as conn:
        return [row[1] for row in conn.exec_driver_sql(f"PRAGMA table_info({table})")]


def _migrate() -> None:
    """
    Tiny hand-rolled migrations -- deliberately not Alembic. This is a
    single-family SQLite file with a handful of tables; a full migration
    framework is more moving parts than the problem needs. Each check is
    idempotent (safe to run on every startup) and only touches tables that
    already exist with the old shape, so a fresh install never hits these
    branches at all -- create_all() below creates new tables with the
    current model shape directly.
    """
    existing_task_columns = _column_names("tasks")
    if existing_task_columns and "status" not in existing_task_columns:
        with engine.begin() as conn:
            conn.exec_driver_sql("ALTER TABLE tasks ADD COLUMN status VARCHAR(20) DEFAULT 'todo'")
            if "is_complete" in existing_task_columns:
                # Phase 3 shipped with a boolean; Phase "task board" replaced
                # it with a three-state status. Preserve existing data.
                conn.exec_driver_sql("UPDATE tasks SET status = 'done' WHERE is_complete = 1")


def init_db() -> None:
    """Create all tables that don't already exist, then run migrations. Called once at startup."""
    # Import models so they register on Base.metadata before create_all runs.
    from app.models import events, people, photos, posts, settings as settings_models, tasks  # noqa: F401

    Base.metadata.create_all(bind=engine)
    _migrate()

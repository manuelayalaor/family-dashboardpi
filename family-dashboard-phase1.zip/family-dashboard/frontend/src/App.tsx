import { useEffect, useState } from "react";
import { api } from "./api/client";
import type { AdguardStatus, CalendarEvent, Person } from "./api/types";
import { CalendarPanel } from "./components/CalendarPanel";
import { CasitaGrid } from "./components/CasitaGrid";
import { HouseRow } from "./components/HouseRow";
import { Layout } from "./components/Layout";
import { useDayPhase } from "./hooks/useDayPhase";

function todayRange(): { start: string; end: string } {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const end = new Date(start);
  end.setDate(end.getDate() + 1);
  return { start: start.toISOString(), end: end.toISOString() };
}

export default function App() {
  const phase = useDayPhase();

  const [people, setPeople] = useState<Person[]>([]);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [adguardStatus, setAdguardStatus] = useState<AdguardStatus | null>(null);
  const [selectedPersonId, setSelectedPersonId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const { start, end } = todayRange();

    Promise.all([api.getPeople(), api.getEvents({ start, end }), api.getAdguardStatus()])
      .then(([peopleRes, eventsRes, adguardRes]) => {
        if (cancelled) return;
        setPeople(peopleRes);
        setEvents(eventsRes);
        setAdguardStatus(adguardRes);
        setError(null);
      })
      .catch((err: Error) => {
        if (!cancelled) setError(err.message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <Layout phase={phase}>
      {error && (
        <div className="card empty-state" style={{ gridColumn: "1 / -1" }}>
          Couldn't reach the dashboard server ({error}). Is the backend running?
        </div>
      )}
      <CalendarPanel events={events} people={people} selectedPersonId={selectedPersonId} loading={loading} />
      <HouseRow people={people} selectedPersonId={selectedPersonId} onSelect={setSelectedPersonId} />
      <CasitaGrid adguardStatus={adguardStatus} />
    </Layout>
  );
}

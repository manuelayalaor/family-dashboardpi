import { useEffect, useState, type ReactNode } from "react";
import type { WeatherStatus } from "../api/types";
import type { DayPhase } from "../hooks/useDayPhase";
import type { Route } from "../lib/router";
import { Sky } from "./Sky";

interface LayoutProps {
  phase: DayPhase;
  weather: WeatherStatus | null;
  route: Route;
  navigate: (path: Route) => void;
  children: ReactNode;
}

const PHASE_ICON: Record<DayPhase, string> = {
  morning: "🌅",
  day: "☀️",
  sunset: "🌇",
  night: "🌙",
};

const CONDITION_ICON: Record<string, string> = {
  clear: "☀️",
  "clear-night": "🌙",
  "partly-cloudy": "⛅",
  cloudy: "☁️",
  fog: "🌫️",
  drizzle: "🌦️",
  rain: "🌧️",
  storm: "⛈️",
  snow: "❄️",
};

const NAV_ITEMS: { path: Route; label: string; icon: string }[] = [
  { path: "/", label: "Home", icon: "🏠" },
  { path: "/calendar", label: "Calendar", icon: "📅" },
  { path: "/admin", label: "Admin", icon: "⚙️" },
];

export function Layout({ phase, weather, route, navigate, children }: LayoutProps) {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000 * 30);
    return () => window.clearInterval(id);
  }, []);

  const timeLabel = now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  const dateLabel = now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });

  return (
    <div className="app-shell" data-phase={phase}>
      <Sky />
      <header className="app-header">
        <button type="button" className="app-title app-title--link" onClick={() => navigate("/")}>
          🏘️ La Familia
        </button>
        <nav className="app-nav" aria-label="Main">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.path}
              type="button"
              className={`app-nav__link ${route === item.path ? "app-nav__link--active" : ""}`}
              onClick={() => navigate(item.path)}
            >
              {item.icon} {item.label}
            </button>
          ))}
        </nav>
        <div className="app-clock">
          <span>{dateLabel}</span>
          <span>{timeLabel}</span>
          {weather?.configured && weather.temperature_c != null && (
            <span className="weather-pill">
              {CONDITION_ICON[weather.condition ?? ""] ?? "🌡️"} {Math.round(weather.temperature_c)}°
            </span>
          )}
          <span className="phase-pill">
            {PHASE_ICON[phase]} {phase}
          </span>
        </div>
      </header>
      <main className="app-main">{children}</main>
    </div>
  );
}

"""
Secret Casita: PIN-gated entry point + private family link feed.

The backend is the actual enforcement point -- every /casita/posts route
depends on auth_service.require_casita_session, not merely hidden behind
a frontend route guard. The frontend hiding the icon/nav entry is a UX
choice; this is the real lock.
"""
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.database import get_db
from app.models.posts import Post
from app.models.settings import Setting, SettingKey
from app.services import auth_service, casita_service

router = APIRouter(tags=["casita"])
settings = get_settings()


def _get_pin_hash(db: Session) -> str | None:
    row = db.get(Setting, SettingKey.CASITA_PIN_HASH)
    return row.value if row else None


def _set_cookie(response: Response) -> None:
    response.set_cookie(
        key=settings.session_cookie_name,
        value=auth_service.create_session_token(),
        httponly=True,
        samesite="lax",
        max_age=settings.session_ttl_minutes * 60,
    )


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------
class PinIn(BaseModel):
    pin: str = Field(min_length=4, max_length=12, pattern=r"^\d+$")


class PostIn(BaseModel):
    text: str | None = Field(default=None, max_length=2000)
    link_url: str | None = Field(default=None, max_length=2048)


class PostOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    text: str | None
    link_url: str | None
    link_title: str | None
    link_description: str | None
    link_image_url: str | None
    link_site_name: str | None
    created_at: datetime


# ---------------------------------------------------------------------------
# PIN setup / login
# ---------------------------------------------------------------------------
@router.get("/casita/status")
def casita_status(db: Session = Depends(get_db)):
    return {"pin_configured": _get_pin_hash(db) is not None}


@router.post("/casita/setup", status_code=201)
def casita_setup(payload: PinIn, response: Response, db: Session = Depends(get_db)):
    if _get_pin_hash(db) is not None:
        raise HTTPException(409, "PIN already configured — use Admin to change it, not setup again")
    db.add(Setting(key=SettingKey.CASITA_PIN_HASH, value=auth_service.hash_pin(payload.pin)))
    db.commit()
    _set_cookie(response)
    return {"ok": True}


@router.post("/casita/login")
def casita_login(payload: PinIn, response: Response, db: Session = Depends(get_db)):
    pin_hash = _get_pin_hash(db)
    if pin_hash is None or not auth_service.verify_pin(payload.pin, pin_hash):
        raise HTTPException(401, "Incorrect PIN")
    _set_cookie(response)
    return {"ok": True}


@router.post("/casita/logout")
def casita_logout(response: Response):
    response.delete_cookie(settings.session_cookie_name)
    return {"ok": True}


@router.delete("/casita/pin")
def reset_pin(response: Response, db: Session = Depends(get_db)):
    """
    Forgot the PIN, or want to change it? There's no "forgot PIN" recovery
    flow (email/SMS make no sense for a local family app) -- this just
    wipes the stored hash so the next visit to the Secret Casita goes
    through setup again, same as a fresh install. Existing posts are kept.
    Reachable from Admin, which has no login wall itself in this app.
    """
    row = db.get(Setting, SettingKey.CASITA_PIN_HASH)
    if row:
        db.delete(row)
        db.commit()
    response.delete_cookie(settings.session_cookie_name)
    return {"ok": True}


# ---------------------------------------------------------------------------
# Private feed -- every route below requires a valid session
# ---------------------------------------------------------------------------
@router.get("/casita/posts", response_model=list[PostOut], dependencies=[Depends(auth_service.require_casita_session)])
def list_posts(db: Session = Depends(get_db)):
    stmt = select(Post).order_by(Post.created_at.desc()).limit(100)
    return db.scalars(stmt).all()


@router.post(
    "/casita/posts",
    response_model=PostOut,
    status_code=201,
    dependencies=[Depends(auth_service.require_casita_session)],
)
async def create_post(payload: PostIn, db: Session = Depends(get_db)):
    if not payload.text and not payload.link_url:
        raise HTTPException(422, "Post needs text, a link, or both")

    post = Post(text=payload.text, link_url=payload.link_url)
    if payload.link_url:
        preview = await casita_service.fetch_link_preview(payload.link_url)
        post.link_title = preview["title"]
        post.link_description = preview["description"]
        post.link_image_url = preview["image"]
        post.link_site_name = preview["site_name"]

    db.add(post)
    db.commit()
    db.refresh(post)
    return post


@router.delete("/casita/posts/{post_id}", status_code=204, dependencies=[Depends(auth_service.require_casita_session)])
def delete_post(post_id: int, db: Session = Depends(get_db)):
    post = db.get(Post, post_id)
    if not post:
        raise HTTPException(404, "Post not found")
    db.delete(post)
    db.commit()

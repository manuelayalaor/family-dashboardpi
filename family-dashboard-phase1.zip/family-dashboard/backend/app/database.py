"""
Database engine and session management.

Uses plain synchronous SQLAlchemy rather than an async driver. On a Pi Zero 2 W
the request volume from a handful of family devices is tiny, so the extra
complexity of async SQLite (aiosqlite) buys nothing but adds overhead and
another moving part to keep working reliably unattended.
"""
from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import get_settings

settings = get_settings()
settings.ensure_directories()

# check_same_thread=False is required because FastAPI may service a single
# session's request in a worker thread different from the one that opened it.
engine = create_engine(
    settings.resolved_database_url,
    connect_args={"check_same_thread": False},
    echo=False,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db() -> Generator[Session, None, None]:
    """FastAPI dependency that yields a request-scoped DB session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db() -> None:
    """Create all tables that don't already exist. Called once at startup."""
    # Import models so they register on Base.metadata before create_all runs.
    from app.models import events, people, photos, posts, settings as settings_models, tasks  # noqa: F401

    Base.metadata.create_all(bind=engine)

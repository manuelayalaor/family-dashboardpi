"""
Admin-configurable settings backed by the generic key/value Setting table.
Currently just the plaza background (Admin -> Dashboard settings), but
structured so slideshow timing and other future toggles follow the same
get/set-by-key pattern instead of each needing their own table.
"""
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.settings import Setting, SettingKey
from app.services import photo_service

router = APIRouter(tags=["settings"])


def _get(db: Session, key: str) -> str | None:
    row = db.get(Setting, key)
    return row.value if row else None


def _set(db: Session, key: str, value: str) -> None:
    row = db.get(Setting, key)
    if row:
        row.value = value
    else:
        db.add(Setting(key=key, value=value))


class PlazaBackgroundOut(BaseModel):
    type: str  # "default" | "color" | "image"
    color: str | None = None
    image_filename: str | None = None


class PlazaBackgroundColorIn(BaseModel):
    color: str = Field(pattern=r"^#[0-9A-Fa-f]{6}$")


def _current_plaza_background(db: Session) -> PlazaBackgroundOut:
    bg_type = _get(db, SettingKey.PLAZA_BACKGROUND_TYPE) or "default"
    return PlazaBackgroundOut(
        type=bg_type,
        color=_get(db, SettingKey.PLAZA_BACKGROUND_COLOR) if bg_type == "color" else None,
        image_filename=_get(db, SettingKey.PLAZA_BACKGROUND_IMAGE) if bg_type == "image" else None,
    )


@router.get("/settings/plaza-background", response_model=PlazaBackgroundOut)
def get_plaza_background(db: Session = Depends(get_db)):
    return _current_plaza_background(db)


@router.put("/settings/plaza-background/color", response_model=PlazaBackgroundOut)
def set_plaza_background_color(payload: PlazaBackgroundColorIn, db: Session = Depends(get_db)):
    _set(db, SettingKey.PLAZA_BACKGROUND_TYPE, "color")
    _set(db, SettingKey.PLAZA_BACKGROUND_COLOR, payload.color)
    db.commit()
    return _current_plaza_background(db)


@router.post("/settings/plaza-background/image", response_model=PlazaBackgroundOut)
async def set_plaza_background_image(file: UploadFile = File(...), db: Session = Depends(get_db)):
    contents = await file.read()
    try:
        # Reuses the photo pipeline (safe filename, format validation) --
        # a background image is stored the same way a photo is, just
        # referenced from a Setting instead of the Photo table. The
        # thumbnail it also generates goes unused here, which is a minor,
        # acceptable amount of waste for how rarely this is called.
        filename, _thumbnail_filename = photo_service.save_upload(contents, file.content_type)
    except photo_service.UnsupportedImageError as exc:
        raise HTTPException(400, str(exc)) from exc

    _set(db, SettingKey.PLAZA_BACKGROUND_TYPE, "image")
    _set(db, SettingKey.PLAZA_BACKGROUND_IMAGE, filename)
    db.commit()
    return _current_plaza_background(db)


@router.delete("/settings/plaza-background", response_model=PlazaBackgroundOut)
def reset_plaza_background(db: Session = Depends(get_db)):
    for key in (SettingKey.PLAZA_BACKGROUND_TYPE, SettingKey.PLAZA_BACKGROUND_COLOR, SettingKey.PLAZA_BACKGROUND_IMAGE):
        row = db.get(Setting, key)
        if row:
            db.delete(row)
    db.commit()
    return _current_plaza_background(db)

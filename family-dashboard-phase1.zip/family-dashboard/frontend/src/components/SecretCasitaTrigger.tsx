import type { Route } from "../lib/router";

interface SecretCasitaTriggerProps {
  navigate: (path: Route) => void;
}

/**
 * The brief calls for a hidden/private casita, PIN-gated (Phase 5 builds
 * the actual lock screen and feed). Renders the same house facade as
 * every other plaza widget (reusing CasitaCard's house classes directly)
 * but skips the floating content panel entirely — no title, no list,
 * nothing set up at the door. Sits in the plaza grid as one more
 * building, not a differently-styled corner icon.
 */
export function SecretCasitaTrigger({ navigate }: SecretCasitaTriggerProps) {
  return (
    <button
      type="button"
      className="secret-casita-trigger"
      onClick={() => navigate("/secret")}
      aria-label="A quiet corner of the plaza"
    >
      <div className="casita-card__house" style={{ background: "var(--color-ink)" }}>
        <div className="house__cornice" />
        <div className="house__balcony-rail" />
        <span className="house__windows">
          <span className="house__shutter-window">
            <span className="house__shutter" />
            <span className="house__glass" />
            <span className="house__shutter" />
          </span>
          <span className="house__shutter-window">
            <span className="house__shutter" />
            <span className="house__glass" />
            <span className="house__shutter" />
          </span>
        </span>
        <div className="house__door">
          <div className="house__door-inner" />
        </div>
      </div>
    </button>
  );
}

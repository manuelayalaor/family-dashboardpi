export interface Person {
  id: number;
  name: string;
  emoji: string;
  house_color: string;
  sort_order: number;
}

export interface CalendarEvent {
  id: number;
  person_id: number | null;
  title: string;
  notes: string | null;
  start_time: string; // ISO 8601
  end_time: string | null;
  all_day: boolean;
  color: string | null;
}

export interface TodaySummary {
  date: string;
  people_count: number;
  event_count: number;
}

export interface AdguardStatus {
  configured: boolean;
  online: boolean | null;
}

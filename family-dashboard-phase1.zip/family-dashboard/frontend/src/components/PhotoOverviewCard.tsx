import { useEffect, useState } from "react";
import { api, photoThumbnailUrl } from "../api/client";
import type { Photo } from "../api/types";
import type { Route } from "../lib/router";
import { MiniCasita } from "./MiniCasita";

interface PhotoOverviewCardProps {
  navigate: (path: Route) => void;
}

const CYCLE_MS = 5000;

export function PhotoOverviewCard({ navigate }: PhotoOverviewCardProps) {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    api
      .getPhotos()
      .then(setPhotos)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (photos.length <= 1) return;
    const id = window.setInterval(() => setIndex((i) => (i + 1) % photos.length), CYCLE_MS);
    return () => window.clearInterval(id);
  }, [photos.length]);

  const current = photos[index];

  return (
    <button type="button" className="card casita-card casita-card--wide photo-overview" onClick={() => navigate("/photos")}>
      <div className="casita-card__header">
        <MiniCasita icon="🖼️" wallColor="var(--color-mustard)" />
        <span className="casita-card__title">Photo Casita</span>
        {photos.length > 0 && <span className="widget-row__meta">{photos.length} photos</span>}
      </div>

      {loading ? (
        <span className="casita-card__subtitle">Loading…</span>
      ) : !current ? (
        <span className="casita-card__subtitle">No photos yet — upload some in Photos.</span>
      ) : (
        <div className="photo-overview__frame">
          <img
            key={current.id}
            className="photo-overview__cycling-image"
            src={photoThumbnailUrl(current.thumbnail_filename)}
            alt={current.caption ?? ""}
            loading="lazy"
          />
          {current.caption && <span className="photo-overview__caption">{current.caption}</span>}
        </div>
      )}
    </button>
  );
}

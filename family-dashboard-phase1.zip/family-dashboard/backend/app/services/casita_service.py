"""
Secret Casita feed logic: creating posts and fetching link previews.

Stub for Phase 1. Implement in Phase 5:

  - fetch_link_preview(url) -> dict: GET the URL (httpx, short timeout,
    reasonable size cap) and parse Open Graph tags (og:title, og:description,
    og:image, og:site_name). On failure or a site that blocks scraping,
    fall back to a bare link card rather than erroring the whole post —
    see the brief's fallback example ("🔗 Instagram / [Open Link]").
  - create_post(...) -> Post: persists text/link/image; calls
    fetch_link_preview when a link_url is present and no preview was
    already supplied by the client.

Session/PIN enforcement lives in auth_service.require_casita_session and is
applied at the router level in api/casita.py, not here.
"""

import { useEffect, useState } from "react";
import { api } from "../api/client";
import type { GroceryItem } from "../api/types";
import { CasitaCard } from "./CasitaCard";

export function GroceryCard() {
  const [items, setItems] = useState<GroceryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api
      .getGroceryItems()
      .then(setItems)
      .finally(() => setLoading(false));
  }, []);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    const name = newName.trim();
    if (!name || submitting) return;
    setSubmitting(true);
    try {
      const item = await api.createGroceryItem({ name });
      setItems((prev) => [item, ...prev]);
      setNewName("");
    } finally {
      setSubmitting(false);
    }
  }

  async function toggleComplete(item: GroceryItem) {
    const updated = await api.updateGroceryItem(item.id, { is_complete: !item.is_complete });
    setItems((prev) => prev.map((i) => (i.id === item.id ? updated : i)));
  }

  async function handleDelete(id: number) {
    setItems((prev) => prev.filter((i) => i.id !== id));
    await api.deleteGroceryItem(id);
  }

  return (
    <CasitaCard title="Grocery" wallColor="var(--color-turquoise)" wide>
      {loading ? (
        <span className="casita-card__subtitle">Loading…</span>
      ) : items.length === 0 ? (
        <span className="casita-card__subtitle">List's empty.</span>
      ) : (
        <ul className="widget-list">
          {items.map((item) => (
            <li key={item.id} className="widget-row">
              <input
                type="checkbox"
                className="widget-row__checkbox"
                checked={item.is_complete}
                onChange={() => toggleComplete(item)}
                aria-label={`Mark "${item.name}" ${item.is_complete ? "not gotten" : "gotten"}`}
              />
              <span className={`widget-row__label ${item.is_complete ? "widget-row__label--done" : ""}`}>
                {item.name}
              </span>
              {item.quantity && <span className="widget-row__meta">{item.quantity}</span>}
              <button
                type="button"
                className="widget-row__delete"
                onClick={() => handleDelete(item.id)}
                aria-label={`Remove "${item.name}"`}
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      )}

      <form className="widget-add" onSubmit={handleAdd}>
        <input
          type="text"
          className="widget-add__input"
          placeholder="Add an item…"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          maxLength={200}
        />
        <button type="submit" className="widget-add__button" disabled={!newName.trim() || submitting}>
          Add
        </button>
      </form>
    </CasitaCard>
  );
}

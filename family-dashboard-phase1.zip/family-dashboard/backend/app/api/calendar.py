from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.events import Event
from app.models.people import Person

router = APIRouter(tags=["calendar"])


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------
class PersonIn(BaseModel):
    name: str = Field(min_length=1, max_length=64)
    emoji: str = "🙂"
    house_color: str = Field(default="#E8A65C", pattern=r"^#[0-9A-Fa-f]{6}$")
    sort_order: int = 0


class PersonUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=64)
    emoji: str | None = None
    house_color: str | None = Field(default=None, pattern=r"^#[0-9A-Fa-f]{6}$")
    sort_order: int | None = None


class PersonOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    emoji: str
    house_color: str
    sort_order: int


class EventIn(BaseModel):
    person_id: int | None = None
    title: str = Field(min_length=1, max_length=200)
    notes: str | None = None
    start_time: datetime
    end_time: datetime | None = None
    all_day: bool = False
    color: str | None = Field(default=None, pattern=r"^#[0-9A-Fa-f]{6}$")


class EventUpdate(BaseModel):
    person_id: int | None = None
    title: str | None = Field(default=None, min_length=1, max_length=200)
    notes: str | None = None
    start_time: datetime | None = None
    end_time: datetime | None = None
    all_day: bool | None = None
    color: str | None = Field(default=None, pattern=r"^#[0-9A-Fa-f]{6}$")


class EventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    person_id: int | None
    title: str
    notes: str | None
    start_time: datetime
    end_time: datetime | None
    all_day: bool
    color: str | None


# ---------------------------------------------------------------------------
# People (houses)
# ---------------------------------------------------------------------------
@router.get("/people", response_model=list[PersonOut])
def list_people(db: Session = Depends(get_db)):
    return db.scalars(select(Person).order_by(Person.sort_order, Person.id)).all()


@router.post("/people", response_model=PersonOut, status_code=201)
def create_person(payload: PersonIn, db: Session = Depends(get_db)):
    person = Person(**payload.model_dump())
    db.add(person)
    db.commit()
    db.refresh(person)
    return person


@router.patch("/people/{person_id}", response_model=PersonOut)
def update_person(person_id: int, payload: PersonUpdate, db: Session = Depends(get_db)):
    person = db.get(Person, person_id)
    if not person:
        raise HTTPException(404, "Person not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(person, field, value)
    db.commit()
    db.refresh(person)
    return person


@router.delete("/people/{person_id}", status_code=204)
def delete_person(person_id: int, db: Session = Depends(get_db)):
    person = db.get(Person, person_id)
    if not person:
        raise HTTPException(404, "Person not found")
    db.delete(person)
    db.commit()


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------
@router.get("/events", response_model=list[EventOut])
def list_events(
    start: datetime | None = None,
    end: datetime | None = None,
    person_id: int | None = None,
    db: Session = Depends(get_db),
):
    """List events, optionally filtered to a date range and/or one person.

    Used both for the month grid (range query) and the 'today' rail /
    house-selection filter (person_id query) on the main calendar widget.
    """
    stmt = select(Event)
    if start is not None:
        stmt = stmt.where(Event.start_time >= start)
    if end is not None:
        stmt = stmt.where(Event.start_time <= end)
    if person_id is not None:
        stmt = stmt.where(Event.person_id == person_id)
    stmt = stmt.order_by(Event.start_time)
    return db.scalars(stmt).all()


@router.post("/events", response_model=EventOut, status_code=201)
def create_event(payload: EventIn, db: Session = Depends(get_db)):
    if payload.person_id is not None and not db.get(Person, payload.person_id):
        raise HTTPException(404, "Person not found")
    event = Event(**payload.model_dump())
    db.add(event)
    db.commit()
    db.refresh(event)
    return event


@router.patch("/events/{event_id}", response_model=EventOut)
def update_event(event_id: int, payload: EventUpdate, db: Session = Depends(get_db)):
    event = db.get(Event, event_id)
    if not event:
        raise HTTPException(404, "Event not found")
    updates = payload.model_dump(exclude_unset=True)
    if "person_id" in updates and updates["person_id"] is not None and not db.get(Person, updates["person_id"]):
        raise HTTPException(404, "Person not found")
    for field, value in updates.items():
        setattr(event, field, value)
    db.commit()
    db.refresh(event)
    return event


@router.delete("/events/{event_id}", status_code=204)
def delete_event(event_id: int, db: Session = Depends(get_db)):
    event = db.get(Event, event_id)
    if not event:
        raise HTTPException(404, "Event not found")
    db.delete(event)
    db.commit()

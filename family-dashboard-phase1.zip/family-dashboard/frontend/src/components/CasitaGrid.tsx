import type { AdguardStatus, Person } from "../api/types";
import { GroceryCard } from "./GroceryCard";
import { MessagesCard } from "./MessagesCard";
import { MiniCasita } from "./MiniCasita";
import { TaskBoard } from "./TaskBoard";

interface CasitaGridProps {
  adguardStatus: AdguardStatus | null;
  people: Person[];
}

function AdguardSubtitle({ status }: { status: AdguardStatus | null }) {
  if (!status || !status.configured) {
    return <span className="casita-card__subtitle">Not connected yet</span>;
  }
  if (status.online) {
    return (
      <span className="casita-card__subtitle">
        <span className="status-dot status-dot--ok" />
        Protected
      </span>
    );
  }
  return (
    <span className="casita-card__subtitle">
      <span className="status-dot status-dot--down" />
      Offline
    </span>
  );
}

export function CasitaGrid({ adguardStatus, people }: CasitaGridProps) {
  return (
    <section className="card plaza" aria-label="More around the plaza">
      <div className="plaza__header">
        <h2 className="plaza__title">🌺 La Plaza</h2>
      </div>
      <div className="casita-grid">
        <div className="card casita-card">
          <div className="casita-card__header">
            <MiniCasita icon="🖼️" wallColor="var(--color-mustard)" />
            <span className="casita-card__title">Photo Casita</span>
          </div>
          <span className="casita-card__subtitle">Coming in Phase 4</span>
        </div>

        <div className="card casita-card">
          <div className="casita-card__header">
            <MiniCasita icon="🔐" wallColor="var(--color-ink)" />
            <span className="casita-card__title">La Casita Secreta</span>
          </div>
          <span className="casita-card__subtitle">Coming in Phase 5</span>
        </div>

        <div className="card casita-card">
          <div className="casita-card__header">
            <MiniCasita icon="🛡️" wallColor="var(--color-azure)" />
            <span className="casita-card__title">AdGuard</span>
          </div>
          <AdguardSubtitle status={adguardStatus} />
        </div>

        <GroceryCard />
        <MessagesCard />
        <TaskBoard people={people} />
      </div>
    </section>
  );
}

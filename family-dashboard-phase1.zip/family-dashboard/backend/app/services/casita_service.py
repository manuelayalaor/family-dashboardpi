"""
Secret Casita feed logic: link preview extraction.

Uses plain regex against the raw HTML for Open Graph tags rather than
pulling in a full HTML parser (BeautifulSoup, lxml) as a new dependency --
we only need three specific meta tags, not general-purpose DOM traversal.
Deliberately tolerant: any failure (timeout, non-HTML response, no OG
tags, blocked scraping) falls back to a bare link per the brief ("If a
site prevents preview extraction, fall back to... 🔗 Open Link") rather
than erroring the whole post out.
"""
import re

import httpx

_TIMEOUT = httpx.Timeout(5.0)
_MAX_BYTES = 2 * 1024 * 1024  # don't pull down an entire video/large file hunting for meta tags

_OG_PATTERNS = {
    "title": re.compile(r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']*)["\']', re.IGNORECASE),
    "description": re.compile(
        r'<meta[^>]+property=["\']og:description["\'][^>]+content=["\']([^"\']*)["\']', re.IGNORECASE
    ),
    "image": re.compile(r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']*)["\']', re.IGNORECASE),
    "site_name": re.compile(
        r'<meta[^>]+property=["\']og:site_name["\'][^>]+content=["\']([^"\']*)["\']', re.IGNORECASE
    ),
}
_TITLE_TAG = re.compile(r"<title[^>]*>([^<]*)</title>", re.IGNORECASE)


async def fetch_link_preview(url: str) -> dict:
    """
    Returns {title, description, image, site_name}, any of which may be
    None. Never raises -- a preview that can't be built is just an empty
    one, and the frontend renders the brief's bare-link fallback for that.
    """
    result: dict[str, str | None] = {"title": None, "description": None, "image": None, "site_name": None}
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT, follow_redirects=True) as client:
            async with client.stream("GET", url, headers={"User-Agent": "Mozilla/5.0 (compatible; FamilyDashboard/1.0)"}) as response:
                if response.status_code >= 400:
                    return result
                content_type = response.headers.get("content-type", "")
                if "text/html" not in content_type:
                    return result
                body = b""
                async for chunk in response.aiter_bytes():
                    body += chunk
                    if len(body) >= _MAX_BYTES:
                        break
        html = body.decode("utf-8", errors="ignore")
    except (httpx.HTTPError, UnicodeDecodeError):
        return result

    for field, pattern in _OG_PATTERNS.items():
        match = pattern.search(html)
        if match:
            result[field] = match.group(1).strip() or None

    if not result["title"]:
        title_match = _TITLE_TAG.search(html)
        if title_match:
            result["title"] = title_match.group(1).strip() or None

    return result

"""
Authentication for the Secret Casita.

Two responsibilities:
  1. Hash / verify the PIN with Argon2 (never store it in plaintext).
  2. Issue a short-lived, HMAC-signed session token after a correct PIN, so
     the PIN doesn't have to be re-sent on every request within a session.

We deliberately avoid a third-party session/JWT library here: a signed
token is ~15 lines of stdlib `hmac` + `hashlib`, which is one fewer
dependency to keep patched on an appliance that runs unattended. The
frontend never sees the PIN hash or the signing key — only the opaque
token, delivered as an httpOnly cookie.

IMPORTANT: The backend is the enforcement point. Every casita route must
depend on `require_casita_session`, not merely hide behind a frontend
route guard.
"""
import base64
import hashlib
import hmac
import time

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from fastapi import Cookie, HTTPException, status

from app.config import get_settings

settings = get_settings()
_hasher = PasswordHasher()


def hash_pin(pin: str) -> str:
    """Hash a PIN for storage. Call once, from the admin 'change PIN' flow."""
    return _hasher.hash(pin)


def verify_pin(pin: str, pin_hash: str) -> bool:
    try:
        return _hasher.verify(pin_hash, pin)
    except VerifyMismatchError:
        return False


def _sign(payload: str) -> str:
    signature = hmac.new(settings.session_secret.encode(), payload.encode(), hashlib.sha256).digest()
    return base64.urlsafe_b64encode(signature).decode().rstrip("=")


def create_session_token() -> str:
    """Issue a token valid for `session_ttl_minutes` from now."""
    expires_at = int(time.time()) + settings.session_ttl_minutes * 60
    payload = str(expires_at)
    return f"{payload}.{_sign(payload)}"


def verify_session_token(token: str | None) -> bool:
    if not token or "." not in token:
        return False
    payload, signature = token.rsplit(".", 1)
    if not hmac.compare_digest(_sign(payload), signature):
        return False
    try:
        expires_at = int(payload)
    except ValueError:
        return False
    return time.time() < expires_at


def require_casita_session(casita_session: str | None = Cookie(default=None)) -> None:
    """FastAPI dependency to protect every Secret Casita route."""
    if not verify_session_token(casita_session):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="PIN required")

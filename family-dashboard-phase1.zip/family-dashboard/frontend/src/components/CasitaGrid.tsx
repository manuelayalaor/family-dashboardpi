import type { AdguardStatus } from "../api/types";

interface CasitaGridProps {
  adguardStatus: AdguardStatus | null;
}

function AdguardSubtitle({ status }: { status: AdguardStatus | null }) {
  if (!status || !status.configured) {
    return <span className="casita-card__subtitle">Not connected yet</span>;
  }
  if (status.online) {
    return (
      <span className="casita-card__subtitle">
        <span className="status-dot status-dot--ok" />
        Protected
      </span>
    );
  }
  return (
    <span className="casita-card__subtitle">
      <span className="status-dot status-dot--down" />
      Offline
    </span>
  );
}

export function CasitaGrid({ adguardStatus }: CasitaGridProps) {
  return (
    <section className="casita-grid" aria-label="More around the plaza">
      <div className="card casita-card">
        <span className="casita-card__icon">🖼️</span>
        <span className="casita-card__title">Photo Casita</span>
        <span className="casita-card__subtitle">Coming in Phase 4</span>
      </div>

      <div className="card casita-card">
        <span className="casita-card__icon">🔐</span>
        <span className="casita-card__title">La Casita Secreta</span>
        <span className="casita-card__subtitle">Coming in Phase 5</span>
      </div>

      <div className="card casita-card">
        <span className="casita-card__icon">🛡️</span>
        <span className="casita-card__title">AdGuard</span>
        <AdguardSubtitle status={adguardStatus} />
      </div>

      <div className="card casita-card">
        <span className="casita-card__icon">📝</span>
        <span className="casita-card__title">Tasks</span>
        <span className="casita-card__subtitle">Coming in Phase 3</span>
      </div>

      <div className="card casita-card">
        <span className="casita-card__icon">🛒</span>
        <span className="casita-card__title">Grocery</span>
        <span className="casita-card__subtitle">Coming in Phase 3</span>
      </div>

      <div className="card casita-card">
        <span className="casita-card__icon">💬</span>
        <span className="casita-card__title">Messages</span>
        <span className="casita-card__subtitle">Coming in Phase 3</span>
      </div>
    </section>
  );
}

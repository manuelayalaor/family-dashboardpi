import type { AdguardStatus, Person } from "../api/types";
import { GroceryCard } from "./GroceryCard";
import { MessagesCard } from "./MessagesCard";
import { TasksCard } from "./TasksCard";

interface CasitaGridProps {
  adguardStatus: AdguardStatus | null;
  people: Person[];
}

function AdguardSubtitle({ status }: { status: AdguardStatus | null }) {
  if (!status || !status.configured) {
    return <span className="casita-card__subtitle">Not connected yet</span>;
  }
  if (status.online) {
    return (
      <span className="casita-card__subtitle">
        <span className="status-dot status-dot--ok" />
        Protected
      </span>
    );
  }
  return (
    <span className="casita-card__subtitle">
      <span className="status-dot status-dot--down" />
      Offline
    </span>
  );
}

export function CasitaGrid({ adguardStatus, people }: CasitaGridProps) {
  return (
    <section className="card plaza" aria-label="More around the plaza">
      <div className="plaza__header">
        <h2 className="plaza__title">🌺 La Plaza</h2>
      </div>
      <div className="casita-grid">
        <div className="card casita-card">
          <span className="casita-card__icon">🖼️</span>
          <span className="casita-card__title">Photo Casita</span>
          <span className="casita-card__subtitle">Coming in Phase 4</span>
        </div>

        <div className="card casita-card">
          <span className="casita-card__icon">🔐</span>
          <span className="casita-card__title">La Casita Secreta</span>
          <span className="casita-card__subtitle">Coming in Phase 5</span>
        </div>

        <div className="card casita-card">
          <span className="casita-card__icon">🛡️</span>
          <span className="casita-card__title">AdGuard</span>
          <AdguardSubtitle status={adguardStatus} />
        </div>

        <TasksCard people={people} />
        <GroceryCard />
        <MessagesCard />
      </div>
    </section>
  );
}

"""
AdGuard Casita: status for the small plaza indicator, stats for the full
page. Both endpoints just delegate to adguard_service, which handles the
"not configured" and "configured but unreachable" cases.
"""
from fastapi import APIRouter

from app.services import adguard_service

router = APIRouter(tags=["adguard"])


@router.get("/adguard/status")
async def adguard_status():
    return await adguard_service.get_status()


@router.get("/adguard/stats")
async def adguard_stats():
    return await adguard_service.get_stats()

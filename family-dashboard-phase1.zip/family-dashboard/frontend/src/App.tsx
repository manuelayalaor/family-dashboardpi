import { useEffect, useState } from "react";
import { api } from "./api/client";
import type { WeatherStatus } from "./api/types";
import { AdminConsole } from "./components/AdminConsole";
import { CalendarView } from "./components/CalendarView";
import { Dashboard } from "./components/Dashboard";
import { Layout } from "./components/Layout";
import { useDayPhase } from "./hooks/useDayPhase";
import { useRoute } from "./lib/router";

export default function App() {
  const phase = useDayPhase();
  const [route, navigate] = useRoute();
  const [weather, setWeather] = useState<WeatherStatus | null>(null);

  useEffect(() => {
    api.getWeather().then(setWeather).catch(() => undefined);
  }, []);

  return (
    <Layout phase={phase} weather={weather} route={route} navigate={navigate}>
      {route === "/" && <Dashboard />}
      {route === "/calendar" && <CalendarView />}
      {route === "/admin" && <AdminConsole navigate={navigate} />}
    </Layout>
  );
}

"""
AdGuard Home API client, against the existing AdGuard Home instance
already running on the Pi. Uses HTTP Basic Auth (adguard_username /
adguard_password from config). Both status and stats are cached briefly
(30s) rather than hit on every dashboard poll -- the Pi Zero 2 W is also
running AdGuard itself, so this stays polite about it.
"""
import time

import httpx

from app.config import get_settings

settings = get_settings()

_TIMEOUT = httpx.Timeout(4.0)
_CACHE_TTL_SECONDS = 30
_status_cache: dict[str, object] = {"expires_at": 0.0, "payload": None}
_stats_cache: dict[str, object] = {"expires_at": 0.0, "payload": None}


def _configured() -> bool:
    return bool(settings.adguard_base_url)


def _auth() -> tuple[str, str] | None:
    if settings.adguard_username and settings.adguard_password:
        return (settings.adguard_username, settings.adguard_password)
    return None


async def get_status() -> dict:
    if not _configured():
        return {"configured": False, "online": None}

    now = time.time()
    if _status_cache["expires_at"] > now and _status_cache["payload"] is not None:
        return _status_cache["payload"]  # type: ignore[return-value]

    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT, auth=_auth()) as client:
            response = await client.get(f"{settings.adguard_base_url}/control/status")
            response.raise_for_status()
            data = response.json()
        payload = {"configured": True, "online": bool(data.get("protection_enabled", True))}
    except (httpx.HTTPError, ValueError):
        # AdGuard down/unreachable is a normal, expected state to show, not
        # a dashboard-breaking error -- surface it as offline, not a 500.
        payload = {"configured": True, "online": False}

    _status_cache["payload"] = payload
    _status_cache["expires_at"] = now + _CACHE_TTL_SECONDS
    return payload


async def get_stats() -> dict:
    empty = {
        "configured": False,
        "requests_today": 0,
        "blocked_today": 0,
        "block_rate": 0.0,
        "top_blocked_domains": [],
    }
    if not _configured():
        return empty

    now = time.time()
    if _stats_cache["expires_at"] > now and _stats_cache["payload"] is not None:
        return _stats_cache["payload"]  # type: ignore[return-value]

    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT, auth=_auth()) as client:
            response = await client.get(f"{settings.adguard_base_url}/control/stats")
            response.raise_for_status()
            data = response.json()
    except (httpx.HTTPError, ValueError):
        payload = {**empty, "configured": True}
        _stats_cache["payload"] = payload
        _stats_cache["expires_at"] = now + _CACHE_TTL_SECONDS
        return payload

    # AdGuard's /control/stats returns per-interval arrays (last N periods,
    # e.g. hourly buckets for a day); today's totals are the sum of those.
    requests_today = sum(data.get("dns_queries", []) or [0])
    blocked_today = sum(data.get("blocked_filtering", []) or [0])
    block_rate = round((blocked_today / requests_today) * 100, 1) if requests_today else 0.0

    top_domains = [
        {"domain": next(iter(entry)), "count": next(iter(entry.values()))}
        for entry in (data.get("top_blocked_domains") or [])[:5]
    ]

    payload = {
        "configured": True,
        "requests_today": requests_today,
        "blocked_today": blocked_today,
        "block_rate": block_rate,
        "top_blocked_domains": top_domains,
    }
    _stats_cache["payload"] = payload
    _stats_cache["expires_at"] = now + _CACHE_TTL_SECONDS
    return payload

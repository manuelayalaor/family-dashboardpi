"""
AdGuard Casita: status for the small plaza indicator, stats for the full
page. Both endpoints delegate to adguard_service, which reads connection
settings (admin-configurable, see api/settings.py) and handles the "not
configured" and "configured but unreachable" cases.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.services import adguard_service

router = APIRouter(tags=["adguard"])


@router.get("/adguard/status")
async def adguard_status(db: Session = Depends(get_db)):
    return await adguard_service.get_status(db)


@router.get("/adguard/stats")
async def adguard_stats(db: Session = Depends(get_db)):
    return await adguard_service.get_stats(db)

import { useEffect, useState, type ReactNode } from "react";
import type { DayPhase } from "../hooks/useDayPhase";

interface LayoutProps {
  phase: DayPhase;
  children: ReactNode;
}

const PHASE_ICON: Record<DayPhase, string> = {
  morning: "🌅",
  day: "☀️",
  sunset: "🌇",
  night: "🌙",
};

export function Layout({ phase, children }: LayoutProps) {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000 * 30);
    return () => window.clearInterval(id);
  }, []);

  const timeLabel = now.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  const dateLabel = now.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });

  return (
    <div className="app-shell" data-phase={phase}>
      <header className="app-header">
        <h1 className="app-title">🏘️ La Familia</h1>
        <div className="app-clock">
          <span>{dateLabel}</span>
          <span>{timeLabel}</span>
          <span className="phase-pill">
            {PHASE_ICON[phase]} {phase}
          </span>
        </div>
      </header>
      <main className="app-main">{children}</main>
    </div>
  );
}

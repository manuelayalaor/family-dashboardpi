import { useEffect, useRef, useState } from "react";
import { api, photoThumbnailUrl } from "../api/client";
import type { Album, Photo } from "../api/types";
import { SlideshowOverlay } from "./SlideshowOverlay";

export function PhotosPage() {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [selectedAlbumId, setSelectedAlbumId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [newAlbumName, setNewAlbumName] = useState("");
  const [slideshowIndex, setSlideshowIndex] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    api.getAlbums().then(setAlbums);
  }, []);

  useEffect(() => {
    setLoading(true);
    api
      .getPhotos(selectedAlbumId ?? undefined)
      .then(setPhotos)
      .finally(() => setLoading(false));
  }, [selectedAlbumId]);

  async function handleFilesSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (files.length === 0) return;
    setUploading(true);
    setUploadError(null);
    try {
      const uploaded = await api.uploadPhotos(files, selectedAlbumId ?? undefined);
      setPhotos((prev) => [...uploaded, ...prev]);
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function handleDelete(id: number) {
    if (!window.confirm("Delete this photo? This can't be undone.")) return;
    setPhotos((prev) => prev.filter((p) => p.id !== id));
    await api.deletePhoto(id);
  }

  async function handleCaptionBlur(photo: Photo, caption: string) {
    if (caption === (photo.caption ?? "")) return;
    await api.updatePhoto(photo.id, { caption: caption || null });
  }

  async function handleAddAlbum(e: React.FormEvent) {
    e.preventDefault();
    const name = newAlbumName.trim();
    if (!name) return;
    const album = await api.createAlbum(name);
    setAlbums((prev) => [...prev, album].sort((a, b) => a.name.localeCompare(b.name)));
    setNewAlbumName("");
  }

  async function handleDeleteAlbum(id: number) {
    if (!window.confirm("Delete this album? Photos in it will move back to All Photos.")) return;
    setAlbums((prev) => prev.filter((a) => a.id !== id));
    if (selectedAlbumId === id) setSelectedAlbumId(null);
    await api.deleteAlbum(id);
  }

  return (
    <div className="card photos-page">
      <div className="photos-page__toolbar">
        <h2 className="task-board-page__title">🖼️ Photo Casita</h2>
        <div className="photos-page__actions">
          <button
            type="button"
            className="widget-add__button"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
          >
            {uploading ? "Uploading…" : "Upload"}
          </button>
          <button
            type="button"
            className="widget-add__button"
            disabled={photos.length === 0}
            onClick={() => setSlideshowIndex(0)}
          >
            ▶ Slideshow
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            multiple
            style={{ display: "none" }}
            onChange={handleFilesSelected}
          />
        </div>
      </div>

      {uploadError && <p className="empty-state">{uploadError}</p>}

      <div className="calendar-view__filter">
        <button
          type="button"
          className={`calendar-view__filter-chip ${selectedAlbumId == null ? "calendar-view__filter-chip--active" : ""}`}
          onClick={() => setSelectedAlbumId(null)}
        >
          All Photos
        </button>
        {albums.map((album) => (
          <button
            key={album.id}
            type="button"
            className={`calendar-view__filter-chip ${selectedAlbumId === album.id ? "calendar-view__filter-chip--active" : ""}`}
            onClick={() => setSelectedAlbumId(album.id)}
          >
            {album.name}
            {selectedAlbumId === album.id && (
              <span
                role="button"
                tabIndex={0}
                className="photos-page__album-delete"
                onClick={(e) => {
                  e.stopPropagation();
                  handleDeleteAlbum(album.id);
                }}
              >
                {" "}
                ✕
              </span>
            )}
          </button>
        ))}
        <form className="photos-page__new-album" onSubmit={handleAddAlbum}>
          <input
            type="text"
            className="widget-add__input"
            placeholder="New album…"
            value={newAlbumName}
            onChange={(e) => setNewAlbumName(e.target.value)}
            maxLength={100}
          />
          <button type="submit" className="calendar-view__nav" aria-label="Add album" disabled={!newAlbumName.trim()}>
            +
          </button>
        </form>
      </div>

      {loading ? (
        <p className="empty-state">Loading…</p>
      ) : photos.length === 0 ? (
        <p className="empty-state">No photos yet — upload some to fill the casita.</p>
      ) : (
        <div className="photo-grid">
          {photos.map((photo, i) => (
            <div key={photo.id} className="photo-grid__item">
              <img
                className="photo-grid__thumb"
                src={photoThumbnailUrl(photo.thumbnail_filename)}
                alt={photo.caption ?? ""}
                loading="lazy"
                onClick={() => setSlideshowIndex(i)}
              />
              <input
                type="text"
                className="photo-grid__caption"
                defaultValue={photo.caption ?? ""}
                placeholder="Add a caption…"
                maxLength={300}
                onBlur={(e) => handleCaptionBlur(photo, e.target.value)}
              />
              <button
                type="button"
                className="widget-row__delete photo-grid__delete"
                aria-label="Delete photo"
                onClick={() => handleDelete(photo.id)}
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      {slideshowIndex != null && (
        <SlideshowOverlay photos={photos} startIndex={slideshowIndex} onClose={() => setSlideshowIndex(null)} />
      )}
    </div>
  );
}

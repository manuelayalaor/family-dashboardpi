import type {
  AdguardStatus,
  Album,
  CalendarEvent,
  CasitaPost,
  CasitaStatus,
  FamilyMessage,
  GroceryItem,
  Person,
  Photo,
  PlazaBackground,
  Task,
  TaskStatus,
  TodaySummary,
  WeatherStatus,
} from "./types";

// Same-origin in production (nginx proxies /api to FastAPI). In `npm run
// dev`, Vite's own dev-server proxy (see vite.config.ts) forwards this to
// the backend, so this can stay a plain relative path in both cases.
const API_BASE = "/api";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const isFormData = init?.body instanceof FormData;
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: "include",
    // Let the browser set its own multipart boundary header for
    // FormData bodies -- forcing application/json here would break uploads.
    headers: init?.body && !isFormData ? { "Content-Type": "application/json" } : undefined,
    ...init,
  });
  if (!res.ok) {
    let detail = "";
    try {
      const body = await res.json();
      detail = body?.detail ? `: ${body.detail}` : "";
    } catch {
      // response wasn't JSON; ignore
    }
    throw new Error(`${path} failed: ${res.status} ${res.statusText}${detail}`);
  }
  if (res.status === 204) {
    return undefined as T;
  }
  return res.json() as Promise<T>;
}

/** Static URLs for the two /media mounts (served by nginx in production, FastAPI directly in dev). */
export const photoOriginalUrl = (filename: string) => `/media/photos/originals/${filename}`;
export const photoThumbnailUrl = (filename: string) => `/media/photos/thumbnails/${filename}`;

export const api = {
  // --- People ---
  getPeople: () => request<Person[]>("/people"),
  createPerson: (input: { name: string; emoji?: string; house_color?: string; sort_order?: number }) =>
    request<Person>("/people", { method: "POST", body: JSON.stringify(input) }),
  updatePerson: (
    id: number,
    input: Partial<Pick<Person, "name" | "emoji" | "house_color" | "sort_order">>,
  ) => request<Person>(`/people/${id}`, { method: "PATCH", body: JSON.stringify(input) }),
  deletePerson: (id: number) => request<void>(`/people/${id}`, { method: "DELETE" }),

  // --- Events ---
  getEvents: (params: { start?: string; end?: string; personId?: number } = {}) => {
    const search = new URLSearchParams();
    if (params.start) search.set("start", params.start);
    if (params.end) search.set("end", params.end);
    if (params.personId != null) search.set("person_id", String(params.personId));
    const qs = search.toString();
    return request<CalendarEvent[]>(`/events${qs ? `?${qs}` : ""}`);
  },
  createEvent: (input: {
    title: string;
    start_time: string;
    end_time?: string | null;
    person_id?: number | null;
    all_day?: boolean;
    notes?: string | null;
  }) => request<CalendarEvent>("/events", { method: "POST", body: JSON.stringify(input) }),
  updateEvent: (
    id: number,
    input: Partial<{
      title: string;
      start_time: string;
      end_time: string | null;
      person_id: number | null;
      all_day: boolean;
      notes: string | null;
    }>,
  ) => request<CalendarEvent>(`/events/${id}`, { method: "PATCH", body: JSON.stringify(input) }),
  deleteEvent: (id: number) => request<void>(`/events/${id}`, { method: "DELETE" }),

  getToday: () => request<TodaySummary>("/dashboard/today"),

  getAdguardStatus: () => request<AdguardStatus>("/adguard/status"),

  getWeather: () => request<WeatherStatus>("/weather"),

  // --- Tasks (board: todo / in_progress / done) ---
  getTasks: () => request<Task[]>("/tasks"),
  createTask: (input: { title: string; assigned_person_id?: number | null; status?: TaskStatus }) =>
    request<Task>("/tasks", { method: "POST", body: JSON.stringify(input) }),
  updateTask: (id: number, input: Partial<Pick<Task, "title" | "assigned_person_id" | "status">>) =>
    request<Task>(`/tasks/${id}`, { method: "PATCH", body: JSON.stringify(input) }),
  deleteTask: (id: number) => request<void>(`/tasks/${id}`, { method: "DELETE" }),

  // --- Grocery ---
  getGroceryItems: () => request<GroceryItem[]>("/grocery"),
  createGroceryItem: (input: { name: string; quantity?: string | null }) =>
    request<GroceryItem>("/grocery", { method: "POST", body: JSON.stringify(input) }),
  updateGroceryItem: (id: number, input: Partial<Pick<GroceryItem, "name" | "quantity" | "is_complete">>) =>
    request<GroceryItem>(`/grocery/${id}`, { method: "PATCH", body: JSON.stringify(input) }),
  deleteGroceryItem: (id: number) => request<void>(`/grocery/${id}`, { method: "DELETE" }),

  // --- Messages ---
  getMessages: () => request<FamilyMessage[]>("/messages"),
  createMessage: (input: { text: string }) =>
    request<FamilyMessage>("/messages", { method: "POST", body: JSON.stringify(input) }),
  deleteMessage: (id: number) => request<void>(`/messages/${id}`, { method: "DELETE" }),

  // --- Photos ---
  getPhotos: (albumId?: number) => {
    const qs = albumId != null ? `?album_id=${albumId}` : "";
    return request<Photo[]>(`/photos${qs}`);
  },
  uploadPhotos: (files: File[], albumId?: number | null) => {
    const form = new FormData();
    for (const file of files) form.append("files", file);
    if (albumId != null) form.append("album_id", String(albumId));
    return request<Photo[]>("/photos", { method: "POST", body: form });
  },
  updatePhoto: (id: number, input: Partial<Pick<Photo, "caption" | "album_id" | "sort_order">>) =>
    request<Photo>(`/photos/${id}`, { method: "PATCH", body: JSON.stringify(input) }),
  deletePhoto: (id: number) => request<void>(`/photos/${id}`, { method: "DELETE" }),

  // --- Albums ---
  getAlbums: () => request<Album[]>("/albums"),
  createAlbum: (name: string) => request<Album>("/albums", { method: "POST", body: JSON.stringify({ name }) }),
  deleteAlbum: (id: number) => request<void>(`/albums/${id}`, { method: "DELETE" }),

  // --- Plaza background ---
  getPlazaBackground: () => request<PlazaBackground>("/settings/plaza-background"),
  setPlazaBackgroundColor: (color: string) =>
    request<PlazaBackground>("/settings/plaza-background/color", { method: "PUT", body: JSON.stringify({ color }) }),
  setPlazaBackgroundImage: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<PlazaBackground>("/settings/plaza-background/image", { method: "POST", body: form });
  },
  resetPlazaBackground: () => request<PlazaBackground>("/settings/plaza-background", { method: "DELETE" }),

  // --- Secret Casita ---
  getCasitaStatus: () => request<CasitaStatus>("/casita/status"),
  casitaSetup: (pin: string) => request<{ ok: boolean }>("/casita/setup", { method: "POST", body: JSON.stringify({ pin }) }),
  casitaLogin: (pin: string) => request<{ ok: boolean }>("/casita/login", { method: "POST", body: JSON.stringify({ pin }) }),
  casitaLogout: () => request<{ ok: boolean }>("/casita/logout", { method: "POST" }),
  getCasitaPosts: () => request<CasitaPost[]>("/casita/posts"),
  createCasitaPost: (input: { text?: string; link_url?: string }) =>
    request<CasitaPost>("/casita/posts", { method: "POST", body: JSON.stringify(input) }),
  deleteCasitaPost: (id: number) => request<void>(`/casita/posts/${id}`, { method: "DELETE" }),
};

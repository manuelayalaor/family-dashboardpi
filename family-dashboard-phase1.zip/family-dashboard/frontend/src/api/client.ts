import type { AdguardStatus, CalendarEvent, Person, TodaySummary, WeatherStatus } from "./types";

// Same-origin in production (nginx proxies /api to FastAPI). In `npm run
// dev`, Vite's own dev-server proxy (see vite.config.ts) forwards this to
// the backend, so this can stay a plain relative path in both cases.
const API_BASE = "/api";

async function request<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, { credentials: "include" });
  if (!res.ok) {
    throw new Error(`${path} failed: ${res.status} ${res.statusText}`);
  }
  return res.json() as Promise<T>;
}

export const api = {
  getPeople: () => request<Person[]>("/people"),

  getEvents: (params: { start?: string; end?: string; personId?: number } = {}) => {
    const search = new URLSearchParams();
    if (params.start) search.set("start", params.start);
    if (params.end) search.set("end", params.end);
    if (params.personId != null) search.set("person_id", String(params.personId));
    const qs = search.toString();
    return request<CalendarEvent[]>(`/events${qs ? `?${qs}` : ""}`);
  },

  getToday: () => request<TodaySummary>("/dashboard/today"),

  getAdguardStatus: () => request<AdguardStatus>("/adguard/status"),

  getWeather: () => request<WeatherStatus>("/weather"),
};

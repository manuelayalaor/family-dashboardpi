import { useEffect, useState } from "react";
import { api } from "../api/client";
import type { FamilyMessage } from "../api/types";
import { relativeTime } from "../lib/datetime";
import { CasitaCard } from "./CasitaCard";

export function MessagesCard() {
  const [messages, setMessages] = useState<FamilyMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [newText, setNewText] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api
      .getMessages()
      .then(setMessages)
      .finally(() => setLoading(false));
  }, []);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    const text = newText.trim();
    if (!text || submitting) return;
    setSubmitting(true);
    try {
      const message = await api.createMessage({ text });
      setMessages((prev) => [message, ...prev]);
      setNewText("");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(id: number) {
    setMessages((prev) => prev.filter((m) => m.id !== id));
    await api.deleteMessage(id);
  }

  return (
    <CasitaCard title="Messages" wallColor="var(--color-coral)" wide>
      {loading ? (
        <span className="casita-card__subtitle">Loading…</span>
      ) : messages.length === 0 ? (
        <span className="casita-card__subtitle">No messages yet.</span>
      ) : (
        <ul className="message-feed">
          {messages.map((message) => (
            <li key={message.id} className="message-bubble">
              <span className="message-bubble__text">{message.text}</span>
              <span className="message-bubble__time">{relativeTime(message.created_at)}</span>
              <button
                type="button"
                className="widget-row__delete"
                onClick={() => handleDelete(message.id)}
                aria-label="Delete message"
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      )}

      <form className="widget-add" onSubmit={handleAdd}>
        <input
          type="text"
          className="widget-add__input"
          placeholder="Leave a note for the family…"
          value={newText}
          onChange={(e) => setNewText(e.target.value)}
          maxLength={500}
        />
        <button type="submit" className="widget-add__button" disabled={!newText.trim() || submitting}>
          Post
        </button>
      </form>
    </CasitaCard>
  );
}

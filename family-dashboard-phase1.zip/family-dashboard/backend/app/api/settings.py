"""
Admin-configurable settings backed by the generic key/value Setting table.
Currently just the plaza background (Admin -> Dashboard settings), but
structured so slideshow timing and other future toggles follow the same
get/set-by-key pattern instead of each needing their own table.
"""
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
import httpx
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.settings import Setting, SettingKey
from app.services import adguard_service, photo_service

router = APIRouter(tags=["settings"])


def _get(db: Session, key: str) -> str | None:
    row = db.get(Setting, key)
    return row.value if row else None


def _set(db: Session, key: str, value: str) -> None:
    row = db.get(Setting, key)
    if row:
        row.value = value
    else:
        db.add(Setting(key=key, value=value))


class PlazaBackgroundOut(BaseModel):
    type: str  # "default" | "color" | "image"
    color: str | None = None
    image_filename: str | None = None


class PlazaBackgroundColorIn(BaseModel):
    color: str = Field(pattern=r"^#[0-9A-Fa-f]{6}$")


def _current_plaza_background(db: Session) -> PlazaBackgroundOut:
    bg_type = _get(db, SettingKey.PLAZA_BACKGROUND_TYPE) or "default"
    return PlazaBackgroundOut(
        type=bg_type,
        color=_get(db, SettingKey.PLAZA_BACKGROUND_COLOR) if bg_type == "color" else None,
        image_filename=_get(db, SettingKey.PLAZA_BACKGROUND_IMAGE) if bg_type == "image" else None,
    )


@router.get("/settings/plaza-background", response_model=PlazaBackgroundOut)
def get_plaza_background(db: Session = Depends(get_db)):
    return _current_plaza_background(db)


@router.put("/settings/plaza-background/color", response_model=PlazaBackgroundOut)
def set_plaza_background_color(payload: PlazaBackgroundColorIn, db: Session = Depends(get_db)):
    _set(db, SettingKey.PLAZA_BACKGROUND_TYPE, "color")
    _set(db, SettingKey.PLAZA_BACKGROUND_COLOR, payload.color)
    db.commit()
    return _current_plaza_background(db)


@router.post("/settings/plaza-background/image", response_model=PlazaBackgroundOut)
async def set_plaza_background_image(file: UploadFile = File(...), db: Session = Depends(get_db)):
    contents = await file.read()
    try:
        # Reuses the photo pipeline (safe filename, format validation) --
        # a background image is stored the same way a photo is, just
        # referenced from a Setting instead of the Photo table. The
        # thumbnail it also generates goes unused here, which is a minor,
        # acceptable amount of waste for how rarely this is called.
        filename, _thumbnail_filename = photo_service.save_upload(contents, file.content_type)
    except photo_service.UnsupportedImageError as exc:
        raise HTTPException(400, str(exc)) from exc

    _set(db, SettingKey.PLAZA_BACKGROUND_TYPE, "image")
    _set(db, SettingKey.PLAZA_BACKGROUND_IMAGE, filename)
    db.commit()
    return _current_plaza_background(db)


@router.delete("/settings/plaza-background", response_model=PlazaBackgroundOut)
def reset_plaza_background(db: Session = Depends(get_db)):
    for key in (SettingKey.PLAZA_BACKGROUND_TYPE, SettingKey.PLAZA_BACKGROUND_COLOR, SettingKey.PLAZA_BACKGROUND_IMAGE):
        row = db.get(Setting, key)
        if row:
            db.delete(row)
    db.commit()
    return _current_plaza_background(db)


# ---------------------------------------------------------------------------
# AdGuard connection
# ---------------------------------------------------------------------------
class AdguardConnectionOut(BaseModel):
    base_url: str | None = None
    username: str | None = None
    password_set: bool = False


class AdguardConnectionIn(BaseModel):
    base_url: str = Field(min_length=1, max_length=500)
    username: str | None = Field(default=None, max_length=200)
    password: str | None = Field(default=None, max_length=200)


def _current_adguard_connection(db: Session) -> AdguardConnectionOut:
    base_url, username, password = adguard_service.get_connection(db)
    return AdguardConnectionOut(base_url=base_url, username=username, password_set=bool(password))


@router.get("/settings/adguard", response_model=AdguardConnectionOut)
def get_adguard_connection(db: Session = Depends(get_db)):
    return _current_adguard_connection(db)


@router.put("/settings/adguard", response_model=AdguardConnectionOut)
def set_adguard_connection(payload: AdguardConnectionIn, db: Session = Depends(get_db)):
    # Trailing slashes cause double-slash URLs when concatenated with
    # /control/status downstream -- strip defensively.
    _set(db, SettingKey.ADGUARD_BASE_URL, payload.base_url.rstrip("/"))
    _set(db, SettingKey.ADGUARD_USERNAME, payload.username or "")
    if payload.password:
        # Blank password field means "leave the existing one alone" (so
        # the form doesn't force re-entering it just to change the
        # address) -- only overwrite when a new one is actually typed.
        _set(db, SettingKey.ADGUARD_PASSWORD, payload.password)
    db.commit()
    adguard_service.invalidate_cache()
    return _current_adguard_connection(db)


@router.delete("/settings/adguard", response_model=AdguardConnectionOut)
def reset_adguard_connection(db: Session = Depends(get_db)):
    for key in (SettingKey.ADGUARD_BASE_URL, SettingKey.ADGUARD_USERNAME, SettingKey.ADGUARD_PASSWORD):
        row = db.get(Setting, key)
        if row:
            db.delete(row)
    db.commit()
    adguard_service.invalidate_cache()
    return _current_adguard_connection(db)


class AdguardTestIn(BaseModel):
    base_url: str = Field(min_length=1, max_length=500)
    username: str | None = None
    password: str | None = None


class AdguardTestOut(BaseModel):
    reachable: bool
    detail: str


@router.post("/settings/adguard/test", response_model=AdguardTestOut)
async def test_adguard_connection(payload: AdguardTestIn, db: Session = Depends(get_db)):
    """
    Tests whatever is currently typed in the form -- NOT necessarily what's
    saved -- so the person can check before committing to it. If the
    password field was left blank (meaning "keep the saved one"), falls
    back to the already-saved password for the test.
    """
    password = payload.password or adguard_service.get_connection(db)[2]
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(4.0)) as client:
            auth = (payload.username, password) if payload.username and password else None
            response = await client.get(f"{payload.base_url.rstrip('/')}/control/status", auth=auth)
        if response.status_code == 401:
            return AdguardTestOut(reachable=False, detail="Reached AdGuard, but the username/password was rejected.")
        response.raise_for_status()
        return AdguardTestOut(reachable=True, detail="Connected successfully.")
    except httpx.ConnectTimeout:
        return AdguardTestOut(reachable=False, detail="Timed out — check the address and port.")
    except httpx.ConnectError:
        return AdguardTestOut(
            reachable=False,
            detail="Couldn't reach that address. If you used 127.0.0.1 or localhost, try host.docker.internal instead.",
        )
    except httpx.HTTPStatusError as exc:
        return AdguardTestOut(reachable=False, detail=f"AdGuard responded with an error ({exc.response.status_code}).")
    except httpx.HTTPError:
        return AdguardTestOut(reachable=False, detail="Couldn't connect — check the address and port.")

import { useCallback, useEffect, useState } from "react";

export type Route = "/" | "/calendar" | "/tasks" | "/photos" | "/admin" | "/secret" | "/adguard";

function normalize(pathname: string): Route {
  if (pathname.startsWith("/admin")) return "/admin";
  if (pathname.startsWith("/calendar")) return "/calendar";
  if (pathname.startsWith("/tasks")) return "/tasks";
  if (pathname.startsWith("/photos")) return "/photos";
  if (pathname.startsWith("/secret")) return "/secret";
  if (pathname.startsWith("/adguard")) return "/adguard";
  return "/";
}

/**
 * Three screens total (dashboard, full calendar, admin) doesn't justify a
 * router dependency on a device this constrained. This is the whole thing:
 * read the pathname, listen for back/forward, expose a navigate() that
 * pushes state. nginx's SPA fallback (see nginx/nginx.conf) makes a direct
 * load of /calendar or /admin work correctly too.
 */
export function useRoute(): [Route, (path: Route) => void] {
  const [route, setRoute] = useState<Route>(() => normalize(window.location.pathname));

  useEffect(() => {
    const onPopState = () => setRoute(normalize(window.location.pathname));
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  const navigate = useCallback((path: Route) => {
    if (path !== window.location.pathname) {
      window.history.pushState({}, "", path);
    }
    setRoute(path);
    window.scrollTo(0, 0);
  }, []);

  return [route, navigate];
}

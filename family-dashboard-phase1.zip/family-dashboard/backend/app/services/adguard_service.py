"""
AdGuard Home API client.

Stub for Phase 1. Implement in Phase 6, using httpx against the existing
AdGuard Home instance already running on the Pi:

  - get_status() -> dict: GET {adguard_base_url}/control/status
    (protected=True/False maps to the ONLINE/OFFLINE indicator).
  - get_stats() -> dict: GET {adguard_base_url}/control/stats and shape it
    into { requests_today, blocked_today, block_rate, top_blocked_domains }
    for api/adguard.py to serve at /api/adguard/stats.

AdGuard Home uses HTTP Basic Auth (adguard_username / adguard_password from
config). Cache stats for a short TTL (e.g. 30-60s) rather than hitting
AdGuard on every dashboard poll — the Pi Zero 2 W is also running AdGuard
itself, so keep this API polite.
"""

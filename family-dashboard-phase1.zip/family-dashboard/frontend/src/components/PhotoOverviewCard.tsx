import { useEffect, useState } from "react";
import { api, photoThumbnailUrl } from "../api/client";
import type { Photo } from "../api/types";
import type { Route } from "../lib/router";
import { MiniCasita } from "./MiniCasita";

interface PhotoOverviewCardProps {
  navigate: (path: Route) => void;
}

export function PhotoOverviewCard({ navigate }: PhotoOverviewCardProps) {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .getPhotos()
      .then(setPhotos)
      .finally(() => setLoading(false));
  }, []);

  const peek = photos[0];

  return (
    <div className="card casita-card">
      <div className="casita-card__header">
        <MiniCasita icon="🖼️" wallColor="var(--color-mustard)" />
        <span className="casita-card__title">Photo Casita</span>
      </div>

      {loading ? (
        <span className="casita-card__subtitle">Loading…</span>
      ) : photos.length === 0 ? (
        <span className="casita-card__subtitle">No photos yet.</span>
      ) : (
        <div className="photo-overview">
          {peek && (
            <img
              className="photo-overview__peek"
              src={photoThumbnailUrl(peek.thumbnail_filename)}
              alt=""
              loading="lazy"
            />
          )}
          <span className="casita-card__subtitle">
            {photos.length} photo{photos.length === 1 ? "" : "s"}
          </span>
        </div>
      )}

      <button type="button" className="widget-add__button tasks-overview__button" onClick={() => navigate("/photos")}>
        Open Photos →
      </button>
    </div>
  );
}

import type { Route } from "../lib/router";

interface SecretCasitaPageProps {
  navigate: (path: Route) => void;
}

export function SecretCasitaPage({ navigate }: SecretCasitaPageProps) {
  return (
    <div className="card secret-casita-page">
      <span className="secret-casita-page__lock">🔒</span>
      <p className="secret-casita-page__text">
        La Casita Secreta locks up properly in Phase 5 — PIN entry and the private family feed.
      </p>
      <button type="button" className="widget-add__button" onClick={() => navigate("/")}>
        Back home
      </button>
    </div>
  );
}

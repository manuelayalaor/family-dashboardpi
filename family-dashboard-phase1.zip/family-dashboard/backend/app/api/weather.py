from fastapi import APIRouter

from app.services import weather_service

router = APIRouter(tags=["weather"])


@router.get("/weather")
async def weather():
    return await weather_service.get_current_weather()

interface MiniCasitaProps {
  icon: string;
  wallColor: string;
}

/**
 * The brief's central metaphor is "each building represents a family
 * member, feature, or service" — Phase 2 only applied the casita look to
 * people. This gives the plaza's feature/service cards (Tasks, Grocery,
 * AdGuard, ...) the same roof-and-facade treatment at card-header scale,
 * so the whole plaza reads as small buildings rather than a mix of houses
 * and plain UI cards.
 */
export function MiniCasita({ icon, wallColor }: MiniCasitaProps) {
  return (
    <span className="mini-casita" aria-hidden="true">
      <span className="mini-casita__roof" />
      <span className="mini-casita__facade" style={{ background: wallColor }}>
        <span className="mini-casita__window" />
        <span className="mini-casita__window" />
      </span>
      <span className="mini-casita__badge">{icon}</span>
    </span>
  );
}

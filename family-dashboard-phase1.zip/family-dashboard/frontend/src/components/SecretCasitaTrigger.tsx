import type { Route } from "../lib/router";

interface SecretCasitaTriggerProps {
  navigate: (path: Route) => void;
}

/**
 * The brief calls for a hidden/private casita, PIN-gated (Phase 5 builds
 * the actual lock screen and feed). This deliberately isn't the shared
 * MiniCasita/CasitaCard used everywhere else: no windows (nothing to peek
 * through — fitting for something meant to be locked), no title, no wall
 * band, no card background. Just a small dark roof-and-facade shape
 * sitting quietly in the plaza corner. It's still a real, comfortably
 * tappable button though — invisible shouldn't mean unusable.
 */
export function SecretCasitaTrigger({ navigate }: SecretCasitaTriggerProps) {
  return (
    <button
      type="button"
      className="secret-casita-trigger"
      onClick={() => navigate("/secret")}
      aria-label="A quiet corner of the plaza"
    >
      <span className="secret-casita-trigger__building">
        <span className="secret-casita-trigger__roof" />
        <span className="secret-casita-trigger__facade" />
      </span>
    </button>
  );
}

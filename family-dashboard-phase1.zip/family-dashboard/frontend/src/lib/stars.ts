export interface Star {
  id: number;
  top: number; // percent
  left: number; // percent
  size: number; // px
  duration: number; // seconds
  delay: number; // seconds
}

/** Small deterministic PRNG (mulberry32) so the star field is stable across renders without needing to store it in state. */
function mulberry32(seed: number): () => number {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function generateStars(count = 45, seed = 1337): Star[] {
  const rand = mulberry32(seed);
  return Array.from({ length: count }, (_, id) => ({
    id,
    top: rand() * 85,
    left: rand() * 100,
    size: 1 + rand() * 1.8,
    duration: 2 + rand() * 3,
    delay: rand() * 4,
  }));
}

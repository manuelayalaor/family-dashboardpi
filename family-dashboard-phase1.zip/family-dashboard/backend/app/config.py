"""
Central configuration for the Family Dashboard backend.

All settings are overridable via environment variables (see docker-compose.yml
and .env.example at the project root). Defaults are chosen to work out of the
box for local development.
"""
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="DASHBOARD_", extra="ignore")

    # --- Core ---
    app_name: str = "Family Dashboard"
    environment: str = "development"  # "development" | "production"

    # --- Storage ---
    # On the Pi this is bind-mounted to persistent storage (see docker-compose.yml).
    data_dir: Path = Path("/data")
    database_url: str | None = None  # if unset, derived from data_dir below
    photos_dir_name: str = "photos"

    # --- CORS ---
    # In production the PWA is served by nginx from the same origin, so this
    # mainly matters for local `vite dev` usage against the API directly.
    cors_origins: list[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]

    # --- Secret Casita ---
    # Session cookie signing key. MUST be overridden in production via
    # DASHBOARD_SESSION_SECRET. A random default is fine for local dev only.
    session_secret: str = "dev-only-change-me"
    session_cookie_name: str = "casita_session"
    session_ttl_minutes: int = 60

    # --- AdGuard Home integration (Phase 6) ---
    adguard_base_url: str | None = None  # e.g. "http://127.0.0.1:3000"
    adguard_username: str | None = None
    adguard_password: str | None = None

    @property
    def database_path(self) -> Path:
        return self.data_dir / "family.db"

    @property
    def resolved_database_url(self) -> str:
        if self.database_url:
            return self.database_url
        return f"sqlite:///{self.database_path}"

    @property
    def photos_dir(self) -> Path:
        return self.data_dir / self.photos_dir_name

    @property
    def photo_originals_dir(self) -> Path:
        return self.photos_dir / "originals"

    @property
    def photo_thumbnails_dir(self) -> Path:
        return self.photos_dir / "thumbnails"

    def ensure_directories(self) -> None:
        for path in (self.data_dir, self.photos_dir, self.photo_originals_dir, self.photo_thumbnails_dir):
            path.mkdir(parents=True, exist_ok=True)


@lru_cache
def get_settings() -> Settings:
    return Settings()

import { useEffect, useState } from "react";
import { api } from "../api/client";
import type { Task, TaskStatus } from "../api/types";
import type { Route } from "../lib/router";
import { CasitaCard } from "./CasitaCard";

interface TasksOverviewCardProps {
  navigate: (path: Route) => void;
}

const STATUS_LABEL: Record<TaskStatus, string> = {
  todo: "To do",
  in_progress: "In progress",
  done: "Done",
};

const MAX_PREVIEW = 5;

export function TasksOverviewCard({ navigate }: TasksOverviewCardProps) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .getTasks()
      .then(setTasks)
      .finally(() => setLoading(false));
  }, []);

  // Not-done first (todo, then in_progress), most-recently-created within each group.
  const preview = [...tasks]
    .filter((t) => t.status !== "done")
    .sort((a, b) => (a.status === b.status ? 0 : a.status === "todo" ? -1 : 1))
    .slice(0, MAX_PREVIEW);
  const remaining = tasks.filter((t) => t.status !== "done").length - preview.length;

  return (
    <CasitaCard title="Tasks" wallColor="var(--color-terracotta-dim)" wide>
      {loading ? (
        <span className="casita-card__subtitle">Loading…</span>
      ) : tasks.length === 0 ? (
        <span className="casita-card__subtitle">Nothing on the board.</span>
      ) : preview.length === 0 ? (
        <span className="casita-card__subtitle">Everything's done. 🎉</span>
      ) : (
        <ul className="widget-list tasks-overview__list">
          {preview.map((task) => (
            <li key={task.id} className="widget-row">
              <span className={`tasks-overview__status-dot tasks-overview__status-dot--${task.status}`} />
              <span className="widget-row__label">{task.title}</span>
              <span className="widget-row__meta">{STATUS_LABEL[task.status]}</span>
            </li>
          ))}
          {remaining > 0 && <li className="tasks-overview__more">+{remaining} more</li>}
        </ul>
      )}

      <button type="button" className="widget-add__button tasks-overview__button" onClick={() => navigate("/tasks")}>
        Open Task Board →
      </button>
    </CasitaCard>
  );
}

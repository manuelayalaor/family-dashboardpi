"""
Secret Casita: PIN-gated entry point + private family link feed.

The signing/hashing primitives already exist in services/auth_service.py
(Argon2 PIN hashing, HMAC-signed session tokens) so Phase 5 mainly needs to
wire up:

  POST /api/casita/login   -> verify_pin against the stored hash
                               (Setting.CASITA_PIN_HASH), set an httpOnly
                               session cookie via create_session_token().
  GET  /api/casita/posts    -> Depends(require_casita_session), list Post rows.
  POST /api/casita/posts    -> Depends(require_casita_session), create a
                               Post, calling casita_service.fetch_link_preview
                               when a link_url is present.

Every route below the login endpoint MUST depend on
`auth_service.require_casita_session` — the frontend hiding the icon behind
a PIN screen is not, by itself, access control.
"""
from fastapi import APIRouter

router = APIRouter(tags=["casita"])


@router.get("/casita/status")
def casita_status():
    """Whether a PIN has been configured yet (drives the admin setup prompt)."""
    return {"pin_configured": False}

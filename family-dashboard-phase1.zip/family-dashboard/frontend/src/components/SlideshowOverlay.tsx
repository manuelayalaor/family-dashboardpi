import { useEffect, useState } from "react";
import { photoOriginalUrl } from "../api/client";
import type { Photo } from "../api/types";

interface SlideshowOverlayProps {
  photos: Photo[];
  startIndex: number;
  onClose: () => void;
}

const ADVANCE_MS = 7000;

export function SlideshowOverlay({ photos, startIndex, onClose }: SlideshowOverlayProps) {
  const [index, setIndex] = useState(startIndex);
  const [playing, setPlaying] = useState(true);

  const goTo = (next: number) => setIndex(((next % photos.length) + photos.length) % photos.length);

  useEffect(() => {
    if (!playing || photos.length <= 1) return;
    const id = window.setInterval(() => goTo(index + 1), ADVANCE_MS);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, index, photos.length]);

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") goTo(index + 1);
      if (e.key === "ArrowLeft") goTo(index - 1);
      if (e.key === " ") {
        e.preventDefault();
        setPlaying((p) => !p);
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index]);

  const current = photos[index];
  if (!current) return null;

  return (
    <div className="slideshow" role="dialog" aria-modal="true" aria-label="Photo slideshow">
      <img key={current.id} className="slideshow__image" src={photoOriginalUrl(current.filename)} alt="" />

      {current.caption && <div className="slideshow__caption">{current.caption}</div>}

      <button type="button" className="slideshow__close" onClick={onClose} aria-label="Close slideshow">
        ✕
      </button>

      <button
        type="button"
        className="slideshow__nav slideshow__nav--prev"
        onClick={() => goTo(index - 1)}
        aria-label="Previous photo"
      >
        ‹
      </button>
      <button
        type="button"
        className="slideshow__nav slideshow__nav--next"
        onClick={() => goTo(index + 1)}
        aria-label="Next photo"
      >
        ›
      </button>

      <div className="slideshow__footer">
        <button
          type="button"
          className="slideshow__play"
          onClick={() => setPlaying((p) => !p)}
          aria-label={playing ? "Pause slideshow" : "Play slideshow"}
        >
          {playing ? "⏸" : "▶"}
        </button>
        <span className="slideshow__counter">
          {index + 1} / {photos.length}
        </span>
      </div>
    </div>
  );
}

"""
Photo Casita.

Phase 1 wires up a stable, non-404 endpoint. Upload, thumbnailing (via
photo_service, Pillow), delete, reorder, and album endpoints are built out
in Phase 4. Uploaded files will be served back to the PWA as static assets
mounted in main.py at /media/photos, never stored inside the frontend build.
"""
from fastapi import APIRouter

router = APIRouter(tags=["photos"])


@router.get("/photos")
def list_photos():
    return []


@router.get("/albums")
def list_albums():
    return []

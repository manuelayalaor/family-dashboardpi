"""
Photo Casita business logic: uploads, thumbnailing, file cleanup.

Filenames are never trusted from the client -- every stored file gets a
fresh uuid4-derived name, and the original extension is validated against
an allowlist before being reused. Thumbnails are always re-encoded as JPEG
regardless of source format (simpler downstream, smaller files) and capped
at 480px on the long edge, since this is a slideshow rendered on a TV or
tablet by a Pi Zero 2 W, not a photo archive serving full-resolution
images on every frame.
"""
import uuid
from pathlib import Path

from fastapi import UploadFile
from PIL import Image, ImageOps

from app.config import get_settings

settings = get_settings()

THUMBNAIL_MAX_SIZE = (480, 480)
ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/png", "image/webp"}
EXT_BY_CONTENT_TYPE = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}


class UnsupportedImageError(ValueError):
    pass


def save_upload(file_bytes: bytes, content_type: str | None) -> tuple[str, str]:
    """
    Writes the original file and a generated thumbnail to disk. Returns
    (filename, thumbnail_filename) for the caller to persist as a Photo row.
    Raises UnsupportedImageError for anything not in ALLOWED_CONTENT_TYPES
    or that Pillow can't decode as an image (protects against a client
    sending an arbitrary file with a spoofed content-type header).
    """
    if content_type not in ALLOWED_CONTENT_TYPES:
        raise UnsupportedImageError(f"Unsupported file type: {content_type}")

    stem = uuid.uuid4().hex
    ext = EXT_BY_CONTENT_TYPE[content_type]
    filename = f"{stem}{ext}"
    thumbnail_filename = f"{stem}_thumb.jpg"

    original_path = settings.photo_originals_dir / filename
    thumbnail_path = settings.photo_thumbnails_dir / thumbnail_filename

    original_path.write_bytes(file_bytes)

    try:
        with Image.open(original_path) as img:
            img.verify()
        with Image.open(original_path) as img:
            img = ImageOps.exif_transpose(img)  # respect phone-camera rotation
            if img.mode not in ("RGB", "L"):
                img = img.convert("RGB")
            img.thumbnail(THUMBNAIL_MAX_SIZE)
            img.save(thumbnail_path, "JPEG", quality=82)
    except Exception as exc:
        original_path.unlink(missing_ok=True)
        raise UnsupportedImageError("File is not a readable image") from exc

    return filename, thumbnail_filename


def delete_files(filename: str, thumbnail_filename: str) -> None:
    (settings.photo_originals_dir / filename).unlink(missing_ok=True)
    (settings.photo_thumbnails_dir / thumbnail_filename).unlink(missing_ok=True)

import { useEffect, useRef, useState } from "react";
import { api, photoOriginalUrl } from "../api/client";
import type { AdguardConnection, PlazaBackground, Person } from "../api/types";
import type { Route } from "../lib/router";

interface AdminConsoleProps {
  navigate: (path: Route) => void;
}

const STARTER_COLORS = ["#E8A63D", "#3AAFA9", "#D9748C", "#1C7293", "#C1522A", "#8C6BB1"];

export function AdminConsole({ navigate }: AdminConsoleProps) {
  const [people, setPeople] = useState<Person[]>([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState("");
  const [newEmoji, setNewEmoji] = useState("🙂");
  const [submitting, setSubmitting] = useState(false);
  const colorDebounce = useRef<Record<number, number>>({});

  const [background, setBackground] = useState<PlazaBackground | null>(null);
  const [bgColorInput, setBgColorInput] = useState("#E8A63D");
  const [bgUploading, setBgUploading] = useState(false);
  const [bgError, setBgError] = useState<string | null>(null);
  const bgFileInputRef = useRef<HTMLInputElement>(null);

  const [resettingPin, setResettingPin] = useState(false);
  const [pinResetMessage, setPinResetMessage] = useState<string | null>(null);

  const [adguardConn, setAdguardConn] = useState<AdguardConnection | null>(null);
  const [agBaseUrl, setAgBaseUrl] = useState("");
  const [agUsername, setAgUsername] = useState("");
  const [agPassword, setAgPassword] = useState("");
  const [agSaving, setAgSaving] = useState(false);
  const [agMessage, setAgMessage] = useState<string | null>(null);
  const [agTesting, setAgTesting] = useState(false);

  useEffect(() => {
    api
      .getPeople()
      .then(setPeople)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    api.getPlazaBackground().then((bg) => {
      setBackground(bg);
      if (bg.type === "color" && bg.color) setBgColorInput(bg.color);
    });
  }, []);

  useEffect(() => {
    api.getAdguardConnection().then((conn) => {
      setAdguardConn(conn);
      setAgBaseUrl(conn.base_url ?? "");
      setAgUsername(conn.username ?? "");
    });
  }, []);

  async function handleAddPerson(e: React.FormEvent) {
    e.preventDefault();
    const name = newName.trim();
    if (!name || submitting) return;
    setSubmitting(true);
    try {
      const color = STARTER_COLORS[people.length % STARTER_COLORS.length];
      const person = await api.createPerson({ name, emoji: newEmoji || "🙂", house_color: color });
      setPeople((prev) => [...prev, person]);
      setNewName("");
      setNewEmoji("🙂");
    } finally {
      setSubmitting(false);
    }
  }

  function updateLocal(id: number, patch: Partial<Person>) {
    setPeople((prev) => prev.map((p) => (p.id === id ? { ...p, ...patch } : p)));
  }

  async function commitField(id: number, patch: Partial<Person>) {
    await api.updatePerson(id, patch);
  }

  function handleColorChange(id: number, color: string) {
    updateLocal(id, { house_color: color });
    window.clearTimeout(colorDebounce.current[id]);
    colorDebounce.current[id] = window.setTimeout(() => commitField(id, { house_color: color }), 400);
  }

  async function handleDelete(id: number) {
    if (!window.confirm("Remove this house? Their events will be kept but unassigned.")) return;
    setPeople((prev) => prev.filter((p) => p.id !== id));
    await api.deletePerson(id);
  }

  async function handleSetBgColor() {
    setBgError(null);
    try {
      setBackground(await api.setPlazaBackgroundColor(bgColorInput));
    } catch (err) {
      setBgError(err instanceof Error ? err.message : "Couldn't set that color");
    }
  }

  async function handleBgFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBgUploading(true);
    setBgError(null);
    try {
      setBackground(await api.setPlazaBackgroundImage(file));
    } catch (err) {
      setBgError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setBgUploading(false);
      if (bgFileInputRef.current) bgFileInputRef.current.value = "";
    }
  }

  async function handleResetBg() {
    setBgError(null);
    setBackground(await api.resetPlazaBackground());
  }

  async function handleResetPin() {
    if (!window.confirm("Reset the Secret Casita PIN? The current PIN stops working immediately — the next visit will ask to set a new one.")) {
      return;
    }
    setResettingPin(true);
    setPinResetMessage(null);
    try {
      await api.casitaResetPin();
      setPinResetMessage("PIN reset. Next visit to La Casita Secreta will prompt for a new one.");
    } catch {
      setPinResetMessage("Something went wrong — try again.");
    } finally {
      setResettingPin(false);
    }
  }

  async function handleTestAdguard() {
    const base_url = agBaseUrl.trim();
    if (!base_url) return;
    setAgTesting(true);
    setAgMessage(null);
    try {
      const result = await api.testAdguardConnection({
        base_url,
        username: agUsername.trim() || undefined,
        password: agPassword.trim() || undefined,
      });
      setAgMessage((result.reachable ? "✅ " : "❌ ") + result.detail);
    } catch (err) {
      setAgMessage(err instanceof Error ? err.message : "Couldn't run the test.");
    } finally {
      setAgTesting(false);
    }
  }

  async function handleSaveAdguard(e: React.FormEvent) {
    e.preventDefault();
    const base_url = agBaseUrl.trim();
    if (!base_url) return;
    setAgSaving(true);
    setAgMessage(null);
    try {
      const conn = await api.setAdguardConnection({
        base_url,
        username: agUsername.trim() || undefined,
        password: agPassword.trim() || undefined,
      });
      setAdguardConn(conn);
      setAgPassword("");
      setAgMessage("Saved — checking connection now applies immediately, no restart needed.");
    } catch (err) {
      setAgMessage(err instanceof Error ? err.message : "Couldn't save those settings.");
    } finally {
      setAgSaving(false);
    }
  }

  async function handleResetAdguard() {
    if (!window.confirm("Disconnect AdGuard? This clears the saved address and credentials.")) return;
    const conn = await api.resetAdguardConnection();
    setAdguardConn(conn);
    setAgBaseUrl("");
    setAgUsername("");
    setAgPassword("");
    setAgMessage("Disconnected.");
  }

  return (
    <div className="admin">
      <section className="card admin__section">
        <h2 className="admin__section-title">People &amp; Houses</h2>
        <p className="admin__section-hint">
          Each person here gets a casita in the neighborhood. Changes save automatically.
        </p>

        {loading ? (
          <p className="empty-state">Loading…</p>
        ) : (
          <ul className="admin__people-list">
            {people.map((person) => (
              <li key={person.id} className="admin__person-row">
                <input
                  type="color"
                  className="admin__color-input"
                  value={person.house_color}
                  onChange={(e) => handleColorChange(person.id, e.target.value)}
                  aria-label={`${person.name}'s house color`}
                />
                <input
                  type="text"
                  className="widget-add__input admin__emoji-input"
                  defaultValue={person.emoji}
                  maxLength={8}
                  aria-label={`${person.name}'s emoji`}
                  onBlur={(e) => {
                    const emoji = e.target.value.trim() || "🙂";
                    updateLocal(person.id, { emoji });
                    commitField(person.id, { emoji });
                  }}
                />
                <input
                  type="text"
                  className="widget-add__input"
                  defaultValue={person.name}
                  maxLength={64}
                  aria-label="Name"
                  onBlur={(e) => {
                    const name = e.target.value.trim();
                    if (!name) return;
                    updateLocal(person.id, { name });
                    commitField(person.id, { name });
                  }}
                />
                <button
                  type="button"
                  className="widget-row__delete"
                  aria-label={`Remove ${person.name}`}
                  onClick={() => handleDelete(person.id)}
                >
                  ✕
                </button>
              </li>
            ))}
          </ul>
        )}

        <form className="widget-add" onSubmit={handleAddPerson}>
          <input
            type="text"
            className="widget-add__input admin__emoji-input"
            value={newEmoji}
            maxLength={8}
            aria-label="New person's emoji"
            onChange={(e) => setNewEmoji(e.target.value)}
          />
          <input
            type="text"
            className="widget-add__input"
            placeholder="Add a family member…"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            maxLength={64}
          />
          <button type="submit" className="widget-add__button" disabled={!newName.trim() || submitting}>
            Add House
          </button>
        </form>
      </section>

      <section className="card admin__section">
        <h2 className="admin__section-title">Calendar</h2>
        <p className="admin__section-hint">
          Events are added, edited, and deleted from the full calendar view itself.
        </p>
        <button type="button" className="widget-add__button" onClick={() => navigate("/calendar")}>
          Open Calendar →
        </button>
      </section>

      <section className="card admin__section">
        <h2 className="admin__section-title">Tasks, Grocery &amp; Messages</h2>
        <p className="admin__section-hint">
          These are managed directly in La Plaza on the home screen — add, check off, and delete right
          from the widgets there.
        </p>
        <button type="button" className="widget-add__button" onClick={() => navigate("/")}>
          Go to La Plaza →
        </button>
      </section>

      <section className="card admin__section">
        <h2 className="admin__section-title">La Plaza Background</h2>
        <p className="admin__section-hint">
          Plain by default, matching the rest of the dashboard. Set a color or upload a picture instead.
        </p>

        <div
          className="admin__bg-preview"
          style={
            background?.type === "color" && background.color
              ? { background: background.color }
              : background?.type === "image" && background.image_filename
                ? {
                    backgroundImage: `url(${photoOriginalUrl(background.image_filename)})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                  }
                : undefined
          }
        >
          {(!background || background.type === "default") && <span>Default</span>}
        </div>

        {bgError && <p className="empty-state">{bgError}</p>}

        <div className="admin__bg-controls">
          <input
            type="color"
            className="admin__color-input"
            value={bgColorInput}
            onChange={(e) => setBgColorInput(e.target.value)}
            aria-label="Plaza background color"
          />
          <span className="admin__bg-hint">tap the circle to pick, then</span>
          <button type="button" className="widget-add__button" onClick={handleSetBgColor}>
            Use this color
          </button>
          <button
            type="button"
            className="widget-add__button"
            onClick={() => bgFileInputRef.current?.click()}
            disabled={bgUploading}
          >
            {bgUploading ? "Uploading…" : "Upload a picture"}
          </button>
          <input
            ref={bgFileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            style={{ display: "none" }}
            onChange={handleBgFileSelected}
          />
          {background && background.type !== "default" && (
            <button type="button" className="calendar-view__cancel" onClick={handleResetBg}>
              Reset to default
            </button>
          )}
        </div>
      </section>

      <section className="card admin__section">
        <h2 className="admin__section-title">La Casita Secreta</h2>
        <p className="admin__section-hint">
          Forgot the PIN, or want to change it? Reset it here — this clears the current PIN so the
          next visit to La Casita Secreta prompts for a new one. Existing posts in the feed are kept.
        </p>
        <button type="button" className="widget-add__button" onClick={handleResetPin} disabled={resettingPin}>
          {resettingPin ? "Resetting…" : "Reset PIN"}
        </button>
        {pinResetMessage && <p className="admin__bg-hint">{pinResetMessage}</p>}
      </section>

      <section className="card admin__section">
        <h2 className="admin__section-title">AdGuard Connection</h2>
        <p className="admin__section-hint">
          Address of your AdGuard Home instance, including port (the container's <em>host</em> port,
          not its internal one — check <code>docker ps</code> if unsure). Use{" "}
          <code>host.docker.internal</code> instead of <code>127.0.0.1</code> or <code>localhost</code>{" "}
          — from inside this app's own container, those point to itself, not the Pi. Example:{" "}
          <code>http://host.docker.internal:8083</code>. Username/password only needed if AdGuard's
          admin login requires them.
        </p>

        <form className="admin__adguard-form" onSubmit={handleSaveAdguard}>
          <input
            type="text"
            className="widget-add__input"
            placeholder="http://host.docker.internal:8083"
            value={agBaseUrl}
            onChange={(e) => setAgBaseUrl(e.target.value)}
          />
          <div className="event-form__row">
            <input
              type="text"
              className="widget-add__input"
              placeholder="Username (optional)"
              value={agUsername}
              onChange={(e) => setAgUsername(e.target.value)}
            />
            <input
              type="password"
              className="widget-add__input"
              placeholder={adguardConn?.password_set ? "Password (leave blank to keep current)" : "Password (optional)"}
              value={agPassword}
              onChange={(e) => setAgPassword(e.target.value)}
            />
          </div>
          <div className="event-form__row">
            <button type="submit" className="widget-add__button" disabled={!agBaseUrl.trim() || agSaving}>
              {agSaving ? "Saving…" : "Save"}
            </button>
            <button
              type="button"
              className="admin__test-button"
              onClick={handleTestAdguard}
              disabled={!agBaseUrl.trim() || agTesting}
            >
              {agTesting ? "Testing…" : "Test connection"}
            </button>
            {adguardConn?.base_url && (
              <button type="button" className="calendar-view__cancel" onClick={handleResetAdguard}>
                Disconnect
              </button>
            )}
          </div>
        </form>
        {agMessage && <p className="admin__bg-hint">{agMessage}</p>}
      </section>

      <section className="card admin__section admin__section--muted">
        <h2 className="admin__section-title">Coming later</h2>
        <p className="admin__section-hint">Display/kiosk settings (Phase 7) will get an admin section once that phase lands.</p>
      </section>
    </div>
  );
}

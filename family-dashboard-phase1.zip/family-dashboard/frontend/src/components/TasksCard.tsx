import { useEffect, useState } from "react";
import { api } from "../api/client";
import type { Person, Task } from "../api/types";

interface TasksCardProps {
  people: Person[];
}

export function TasksCard({ people }: TasksCardProps) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [newTitle, setNewTitle] = useState("");
  const [newAssignee, setNewAssignee] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api
      .getTasks()
      .then(setTasks)
      .finally(() => setLoading(false));
  }, []);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    const title = newTitle.trim();
    if (!title || submitting) return;
    setSubmitting(true);
    try {
      const task = await api.createTask({
        title,
        assigned_person_id: newAssignee ? Number(newAssignee) : null,
      });
      setTasks((prev) => [task, ...prev]);
      setNewTitle("");
      setNewAssignee("");
    } finally {
      setSubmitting(false);
    }
  }

  async function toggleComplete(task: Task) {
    const updated = await api.updateTask(task.id, { is_complete: !task.is_complete });
    setTasks((prev) => prev.map((t) => (t.id === task.id ? updated : t)));
  }

  async function handleDelete(id: number) {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    await api.deleteTask(id);
  }

  const personFor = (id: number | null) => (id == null ? null : people.find((p) => p.id === id));

  return (
    <div className="card casita-card casita-card--wide">
      <span className="casita-card__icon">📝</span>
      <span className="casita-card__title">Tasks</span>

      {loading ? (
        <span className="casita-card__subtitle">Loading…</span>
      ) : tasks.length === 0 ? (
        <span className="casita-card__subtitle">Nothing on the list.</span>
      ) : (
        <ul className="widget-list">
          {tasks.map((task) => {
            const assignee = personFor(task.assigned_person_id);
            return (
              <li key={task.id} className="widget-row">
                <input
                  type="checkbox"
                  className="widget-row__checkbox"
                  checked={task.is_complete}
                  onChange={() => toggleComplete(task)}
                  aria-label={`Mark "${task.title}" ${task.is_complete ? "incomplete" : "complete"}`}
                />
                <span className={`widget-row__label ${task.is_complete ? "widget-row__label--done" : ""}`}>
                  {task.title}
                </span>
                {assignee && <span className="widget-row__meta">{assignee.emoji}</span>}
                <button
                  type="button"
                  className="widget-row__delete"
                  onClick={() => handleDelete(task.id)}
                  aria-label={`Delete "${task.title}"`}
                >
                  ✕
                </button>
              </li>
            );
          })}
        </ul>
      )}

      <form className="widget-add" onSubmit={handleAdd}>
        <input
          type="text"
          className="widget-add__input"
          placeholder="Add a task…"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          maxLength={200}
        />
        {people.length > 0 && (
          <select
            className="widget-add__input"
            style={{ flex: "0 0 auto", width: "auto" }}
            value={newAssignee}
            onChange={(e) => setNewAssignee(e.target.value)}
            aria-label="Assign to"
          >
            <option value="">Unassigned</option>
            {people.map((p) => (
              <option key={p.id} value={p.id}>
                {p.emoji} {p.name}
              </option>
            ))}
          </select>
        )}
        <button type="submit" className="widget-add__button" disabled={!newTitle.trim() || submitting}>
          Add
        </button>
      </form>
    </div>
  );
}

export interface Person {
  id: number;
  name: string;
  emoji: string;
  house_color: string;
  sort_order: number;
}

export interface CalendarEvent {
  id: number;
  person_id: number | null;
  title: string;
  notes: string | null;
  start_time: string; // ISO 8601
  end_time: string | null;
  all_day: boolean;
  color: string | null;
}

export interface TodaySummary {
  date: string;
  people_count: number;
  event_count: number;
}

export interface AdguardStatus {
  configured: boolean;
  online: boolean | null;
}

export interface WeatherStatus {
  configured: boolean;
  temperature_c: number | null;
  condition: string | null;
}

export type TaskStatus = "todo" | "in_progress" | "done";

export interface Task {
  id: number;
  title: string;
  assigned_person_id: number | null;
  status: TaskStatus;
}

export interface GroceryItem {
  id: number;
  name: string;
  quantity: string | null;
  category: string | null;
  is_complete: boolean;
}

export interface FamilyMessage {
  id: number;
  text: string;
  created_at: string;
  expires_at: string | null;
}

export interface Photo {
  id: number;
  filename: string;
  thumbnail_filename: string;
  caption: string | null;
  album_id: number | null;
  sort_order: number;
}

export interface Album {
  id: number;
  name: string;
}

export interface PlazaBackground {
  type: "default" | "color" | "image";
  color: string | null;
  image_filename: string | null;
}

export interface CasitaStatus {
  pin_configured: boolean;
}

export interface CasitaPost {
  id: number;
  text: string | null;
  link_url: string | null;
  link_title: string | null;
  link_description: string | null;
  link_image_url: string | null;
  link_site_name: string | null;
  created_at: string;
}

"""
Tasks, grocery list, and family messages.

Phase 1 wires this router up so the frontend has a stable, non-404 endpoint
to point placeholder casitas at. Full CRUD (add/complete/assign/delete for
tasks and grocery items, post/expire for messages) is built out in Phase 3
against the Task / GroceryItem / Message models already defined in
app/models/tasks.py.
"""
from fastapi import APIRouter

router = APIRouter(tags=["tasks"])


@router.get("/tasks")
def list_tasks():
    return []


@router.get("/grocery")
def list_grocery_items():
    return []


@router.get("/messages")
def list_messages():
    return []

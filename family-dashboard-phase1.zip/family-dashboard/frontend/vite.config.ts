import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      includeAssets: ["icons/icon-192.png", "icons/icon-512.png"],
      manifest: {
        name: "Family Dashboard",
        short_name: "Family",
        description: "A living digital neighborhood for the family.",
        theme_color: "#C1522A",
        background_color: "#F4ECDC",
        display: "standalone",
        orientation: "any",
        start_url: "/",
        icons: [
          { src: "icons/icon-192.png", sizes: "192x192", type: "image/png" },
          { src: "icons/icon-512.png", sizes: "512x512", type: "image/png" },
          { src: "icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
        ],
      },
      workbox: {
        // Runtime API calls are same-origin JSON, not app-shell assets —
        // never let the service worker cache them stale on a live dashboard.
        navigateFallbackDenylist: [/^\/api\//, /^\/media\//],
      },
    }),
  ],
  server: {
    // Lets `npm run dev` hit the FastAPI container/process without CORS
    // fuss; in production nginx does this same proxying (see nginx.conf).
    proxy: {
      "/api": { target: "http://localhost:8000", changeOrigin: true },
      "/media": { target: "http://localhost:8000", changeOrigin: true },
    },
  },
  build: {
    // Keep the shipped bundle lean — this is fetched by a Pi Zero 2 W over
    // its own LAN/nginx, and rendered by whatever's driving the kiosk screen.
    target: "es2020",
    sourcemap: false,
  },
});

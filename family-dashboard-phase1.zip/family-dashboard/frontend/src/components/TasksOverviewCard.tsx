import { useEffect, useState } from "react";
import { api } from "../api/client";
import type { Task } from "../api/types";
import type { Route } from "../lib/router";
import { MiniCasita } from "./MiniCasita";

interface TasksOverviewCardProps {
  navigate: (path: Route) => void;
}

export function TasksOverviewCard({ navigate }: TasksOverviewCardProps) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .getTasks()
      .then(setTasks)
      .finally(() => setLoading(false));
  }, []);

  const todoCount = tasks.filter((t) => t.status === "todo").length;
  const inProgressCount = tasks.filter((t) => t.status === "in_progress").length;
  const doneCount = tasks.filter((t) => t.status === "done").length;

  return (
    <div className="card casita-card">
      <div className="casita-card__header">
        <MiniCasita icon="📝" wallColor="var(--color-terracotta-dim)" />
        <span className="casita-card__title">Tasks</span>
      </div>

      {loading ? (
        <span className="casita-card__subtitle">Loading…</span>
      ) : tasks.length === 0 ? (
        <span className="casita-card__subtitle">Nothing on the board.</span>
      ) : (
        <div className="tasks-overview__counts">
          <span>
            <strong>{todoCount}</strong> to do
          </span>
          <span>
            <strong>{inProgressCount}</strong> in progress
          </span>
          <span>
            <strong>{doneCount}</strong> done
          </span>
        </div>
      )}

      <button type="button" className="widget-add__button tasks-overview__button" onClick={() => navigate("/tasks")}>
        Open Task Board →
      </button>
    </div>
  );
}

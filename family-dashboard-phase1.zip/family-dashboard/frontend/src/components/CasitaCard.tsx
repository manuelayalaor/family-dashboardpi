import type { KeyboardEvent, ReactNode } from "react";

interface CasitaCardProps {
  title: string;
  wallColor: string;
  wide?: boolean;
  headerRight?: ReactNode;
  onClick?: () => void;
  children: ReactNode;
}

/**
 * Every feature/service in the plaza (Tasks, Grocery, Messages, Photos,
 * AdGuard) renders through this — same flat-roof/cornice language as the
 * family houses, but styled as an individual shop-front: the "arch" is a
 * real architectural opening (an elliptical border-radius, not a
 * decorative shape) and the widget's actual content sits inside it, like
 * looking through an open doorway, rather than a flat card body under a
 * plain color header bar.
 */
export function CasitaCard({ title, wallColor, wide, headerRight, onClick, children }: CasitaCardProps) {
  function handleKeyDown(e: KeyboardEvent<HTMLDivElement>) {
    if (!onClick) return;
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      onClick();
    }
  }

  return (
    <div
      className={`card casita-card ${wide ? "casita-card--wide" : ""} ${onClick ? "casita-card--clickable" : ""}`}
      style={{ background: wallColor }}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onClick={onClick}
      onKeyDown={handleKeyDown}
    >
      <div className="casita-card__cornice" />
      <div className="casita-card__wall">
        <span className="casita-card__title">{title}</span>
        {headerRight}
      </div>
      <div className="casita-card__arch">{children}</div>
      <div className="casita-card__sill" style={{ background: wallColor }} />
    </div>
  );
}

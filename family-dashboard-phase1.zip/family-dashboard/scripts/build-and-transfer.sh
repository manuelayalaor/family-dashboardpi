#!/usr/bin/env bash
# Build the Family Dashboard images on THIS machine (not the Pi), targeting
# the Pi's CPU architecture, then transfer + load them over SSH.
#
# Why: the Pi Zero 2 W has 512MB of RAM. `npm install` plus compiling
# argon2-cffi/Pillow from source (backend/Dockerfile) can exceed that and
# force the kernel into swap-thrashing on the SD card, which looks like a
# total hang rather than a clean OOM kill. Building here and shipping
# finished images avoids all of that — the Pi only ever runs `docker load`
# and `docker compose up`, no compiling.
#
# Usage:
#   ./scripts/build-and-transfer.sh pi@my-pi.tailnet-name.ts.net
#
# With no argument, it just builds + saves the tarball locally without
# transferring, so you can scp/rsync it yourself.
set -euo pipefail

PI_HOST="${1:-}"
TARBALL="family-dashboard-images.tar"

if [[ -z "$PI_HOST" ]]; then
  echo "No Pi host given — will build and save ${TARBALL} locally only."
  echo "(Run again as: $0 pi@<tailscale-hostname> to also transfer + load it.)"
else
  echo "Detecting Pi architecture via ssh ${PI_HOST}..."
  PI_ARCH="$(ssh "$PI_HOST" uname -m)"
  case "$PI_ARCH" in
    aarch64) PLATFORM="linux/arm64" ;;
    armv7l)  PLATFORM="linux/arm/v7" ;;
    *)
      echo "Unrecognized Pi architecture '${PI_ARCH}' — set PLATFORM manually and rerun." >&2
      exit 1
      ;;
  esac
  echo "Pi reports ${PI_ARCH} -> building for ${PLATFORM}"
fi

# Default to arm64 (64-bit Raspberry Pi OS) if we couldn't detect a host.
PLATFORM="${PLATFORM:-linux/arm64}"

docker buildx inspect pi-builder >/dev/null 2>&1 || docker buildx create --name pi-builder
docker buildx use pi-builder

echo "Building backend for ${PLATFORM}..."
docker buildx build --platform "$PLATFORM" -t family-dashboard-backend:latest ./backend --load

echo "Building frontend for ${PLATFORM}..."
docker buildx build --platform "$PLATFORM" -t family-dashboard-web:latest -f frontend/Dockerfile . --load

echo "Saving both images to ${TARBALL}..."
docker save family-dashboard-backend:latest family-dashboard-web:latest -o "$TARBALL"
ls -lh "$TARBALL"

if [[ -n "$PI_HOST" ]]; then
  echo "Transferring to ${PI_HOST}..."
  scp "$TARBALL" "${PI_HOST}:~/family-dashboard/${TARBALL}"

  echo "Loading images on the Pi (no build, no npm, no compiling)..."
  ssh "$PI_HOST" "cd ~/family-dashboard && docker load -i ${TARBALL} && docker compose up -d"

  echo "Done. Dashboard should be starting at http://<pi>:8080"
fi

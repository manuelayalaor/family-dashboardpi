# 🏘️ Family Dashboard

A living digital neighborhood, inspired by Old San Juan, that runs as the
family's always-on calendar and hub — primarily on a Raspberry Pi Zero 2 W.

This is the **Phase 1 (Foundation)** scaffold: React PWA + FastAPI + SQLite +
Docker Compose + nginx, with a basic responsive layout, wired end-to-end and
deployable to a Pi today. The Old San Juan neighborhood visuals, photo
slideshow, Secret Casita, AdGuard stats, and family utilities are stubbed in
place (see **Roadmap** below) so each later phase has a stable contract to
build against.

## Architecture

```
                    TAILSCALE
                        │
                        ▼
              Raspberry Pi Zero 2 W
                        │
             ┌──────────┴──────────┐
             │                     │
          nginx :8080          FastAPI :8000
        (serves the PWA,      (internal only,
         proxies /api,         not published
         proxies /media)        to the host)
             │                     │
          React PWA              SQLite
                                    │
                              /data/family.db
                              /data/photos/
```

`web` (nginx) is the only port exposed on the host. It serves the built
static PWA and reverse-proxies `/api/*` and `/media/*` to the `backend`
service over the private Docker network — the browser never talks to
FastAPI directly, in dev or production.

## Repository layout

```
family-dashboard/
├── docker-compose.yml
├── .env.example
├── backend/            FastAPI app (see backend/app for the module breakdown)
├── frontend/           React + TypeScript + Vite PWA
└── nginx/nginx.conf    Reverse proxy + static file serving
```

## Local development

Requires Python 3.12+ and Node 20+.

**Backend** (http://localhost:8000):

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
DASHBOARD_DATA_DIR=./dev-data uvicorn app.main:app --reload
```

**Frontend** (http://localhost:5173, proxies `/api` to the backend above):

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173 — you should see an empty neighborhood ("No
houses yet — add your family in Admin"). The Admin UI itself lands later in
the roadmap; until then, add a person and an event directly against the API
to see the calendar populate:

```bash
curl -X POST http://localhost:8000/api/people \
  -H 'Content-Type: application/json' \
  -d '{"name": "Dad", "emoji": "👨", "house_color": "#C1522A"}'

curl -X POST http://localhost:8000/api/events \
  -H 'Content-Type: application/json' \
  -d '{"person_id": 1, "title": "Family Dinner", "start_time": "2026-08-10T18:00:00"}'
```

FastAPI's interactive docs are available at http://localhost:8000/docs while
developing.

## Deploying to the Raspberry Pi

These steps assume Raspberry Pi OS (64-bit — check with `uname -m` on the
Pi; it should print `aarch64`, not `armv7l`) on the Pi Zero 2 W, with
Tailscale and AdGuard Home already installed per the project brief.

> ⚠️ **Never run `docker compose build` (or `up --build`) on the Pi Zero 2
> W itself.** The frontend build stage runs `npm install`, which alone can
> exceed the Pi's 512MB of RAM and send it into SD-card swap thrashing —
> that's what caused the hang-and-unplug. Both paths below build the
> images somewhere else and only ever `docker pull`/`docker load` on the
> Pi.

You need SSH access to the Pi from whatever device you're setting up from
— if you don't already have an app for that, [Termius](https://termius.com)
has a free tier that's plenty for one host.

### Option A — no spare computer (build via GitHub Actions, free)

This does the actual building on GitHub's servers instead of any device
you own, and needs nothing but Safari on the iPad and SSH access to the
Pi.

1. **Get the project onto GitHub.** Sign in (or sign up — free) at
   github.com in Safari, create a new repository (e.g. `family-dashboard`,
   Private is fine), then **Add file → Upload files** and upload just the
   `.zip` I gave you as a single file — no need to unzip it first, no
   folder drag-and-drop, no git app required. Commit it.

2. **Add the build workflow.** In that same repo: **Add file → Create new
   file**, name it exactly `.github/workflows/build.yml` (typing the `/`
   makes GitHub create the folders), and paste in the workflow text —
   it's also reproduced in the chat reply that pointed you here, since
   GitHub can't preview file contents inside an uploaded `.zip` for you to
   copy from. Commit.

3. **Allow the workflow to publish images.** In the repo: **Settings →
   Actions → General → Workflow permissions** → select **"Read and write
   permissions"** → Save. (Without this, the last step of the build fails
   with a permissions error when it tries to push to the registry.)

4. **Run it.** Go to the **Actions** tab → "Build and publish Pi images" →
   **Run workflow**. It unzips the project, builds both images for
   `arm64`, and pushes them to GitHub's container registry (GHCR) under
   your username. Takes roughly 10–15 minutes — that's GitHub's hardware
   doing the work, not the Pi, so there's nothing to babysit.

5. **Create a token so the Pi can download the images.** GitHub → your
   avatar → **Settings → Developer settings → Personal access tokens →
   Tokens (classic) → Generate new token**, scope: `read:packages`. Copy
   the token somewhere safe — you'll paste it once on the Pi.

6. **On the Pi**, over SSH:

   ```bash
   # copy the zip onto the Pi however's easiest from the iPad (scp, rsync,
   # AirDrop-to-Files then SFTP, curl from a share link, etc), into your
   # home directory, then:
   cd ~
   unzip -o family-dashboard-phase1.zip     # creates ~/family-dashboard/
   cd family-dashboard

   cp .env.example .env
   python3 -c "import secrets; print(secrets.token_hex(32))"   # paste into DASHBOARD_SESSION_SECRET in .env
   nano .env   # also set IMAGE_PREFIX=ghcr.io/<your-github-username>/

   echo "<paste your token here>" | docker login ghcr.io -u <your-github-username> --password-stdin

   docker compose pull
   docker compose up -d
   docker compose ps        # both services should show healthy/running
   ```

   No `npm install`, no compiler, nothing but downloading already-built
   layers — this is the part that's safe on 512MB of RAM.

7. **Future updates:** re-upload the changed zip to the GitHub repo, the
   workflow re-runs automatically (or trigger it manually from the Actions
   tab), then on the Pi just run `docker compose pull && docker compose up
   -d` again.

### Option B — if you get access to a computer later

A laptop/desktop with Docker can build cross-platform images directly and
skip GitHub entirely:

```bash
# on that computer, inside the project folder:
./scripts/build-and-transfer.sh pi@<tailscale-hostname>
```

This detects the Pi's CPU architecture over SSH, cross-builds both images,
and transfers + loads them — see the script for the equivalent manual
`docker buildx build` / `docker save` / `scp` / `docker load` commands if
you'd rather run them by hand.

### Common setup (either option)

**Install Docker on the Pi** first, if it isn't already:

```bash
curl -sSL https://get.docker.com | sh
sudo usermod -aG docker $USER
# log out and back in for the group change to take effect
```

**Check the port:** AdGuard Home commonly already uses port 80 (or 3000
during setup) on this same Pi. `docker-compose.yml` publishes the
dashboard on **8080** by default to avoid that collision — confirm nothing
else on the Pi uses 8080, or change the left-hand side of the `ports:`
mapping.

**Add swap as a safety net**, regardless of which option you use — this
won't make an on-device build fast, but it turns any future memory spike
into graceful slowdown instead of a hard lockup:

```bash
sudo dphys-swapfile swapoff
sudo sed -i 's/^CONF_SWAPSIZE=.*/CONF_SWAPSIZE=512/' /etc/dphys-swapfile
sudo dphys-swapfile setup
sudo dphys-swapfile swapon
```

Once running, the dashboard is at `http://<pi-tailscale-ip>:8080` from any
device on your tailnet. `./data/` on the Pi holds `family.db` and
`photos/` — back this directory up periodically; it's the entire state of
the dashboard.

### Kiosk mode (optional, for a wall-mounted display)

Point Chromium at the dashboard in fullscreen kiosk mode on whatever device
drives the mounted screen (this can be the Pi itself with a display
attached, or a separate always-on tablet/TV):

```bash
chromium-browser --kiosk --noerrdialogs --disable-infobars \
  --disable-session-crashed-bubble \
  "http://localhost:8080"
```

To start this automatically on boot, add it to that device's autostart
(e.g. `~/.config/lxsession/LXDE-pi/autostart` on Raspberry Pi OS with
Desktop, or a systemd user service). This lands more fully in **Phase 7**.

## Roadmap

Phase 1 (this scaffold) is done: PWA shell, FastAPI, SQLite, Docker Compose,
nginx, responsive layout, working calendar CRUD, Pi-deployable.

| Phase | Focus |
|---|---|
| 2 | Old San Juan visuals — houses, plaza, day/night environment, weather |
| 3 | Tasks, grocery list, family messages |
| 4 | Photo Casita — upload, thumbnails, slideshow, albums |
| 5 | Secret Casita — PIN auth (primitives already in `auth_service.py`), private link feed |
| 6 | AdGuard Casita — live status/stats from the AdGuard Home API |
| 7 | Kiosk polish — autostart, animations, offline behavior, backups |

An Admin UI (people/calendar/photos/tasks/messages/PIN/display settings, per
the brief) is threaded through Phases 2–7 alongside the feature it manages,
rather than being one big Phase-8 push.

from datetime import datetime, timezone

from sqlalchemy import DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class Setting(Base):
    """
    Generic key/value store for admin-configurable, rarely-read values:
    slideshow duration, the Secret Casita PIN hash, theme toggles, etc.
    Keeps us from adding a new migration for every small admin toggle.
    """

    __tablename__ = "settings"

    key: Mapped[str] = mapped_column(String(100), primary_key=True)
    value: Mapped[str] = mapped_column(Text, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc)
    )


# Well-known setting keys, collected here so callers don't hand-type strings.
class SettingKey:
    CASITA_PIN_HASH = "casita_pin_hash"
    SLIDESHOW_INTERVAL_SECONDS = "slideshow_interval_seconds"
    CALENDAR_PHOTO_ROTATION_SECONDS = "calendar_photo_rotation_seconds"

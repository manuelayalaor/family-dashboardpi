"""
Tasks, grocery list, and family messages — the three small utility casitas
around the plaza. Deliberately simple CRUD (no categories UI, no due
dates, no reordering) matching the brief's "V1 should primarily focus on"
scope for these secondary features; the calendar stays the star widget.
"""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.people import Person
from app.models.tasks import GroceryItem, Message, Task

router = APIRouter(tags=["tasks"])


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------
class TaskIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    assigned_person_id: int | None = None


class TaskUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=200)
    assigned_person_id: int | None = None
    is_complete: bool | None = None


class TaskOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    assigned_person_id: int | None
    is_complete: bool


class GroceryItemIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    quantity: str | None = Field(default=None, max_length=50)
    category: str | None = Field(default=None, max_length=50)


class GroceryItemUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    quantity: str | None = Field(default=None, max_length=50)
    category: str | None = Field(default=None, max_length=50)
    is_complete: bool | None = None


class GroceryItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    quantity: str | None
    category: str | None
    is_complete: bool


class MessageIn(BaseModel):
    text: str = Field(min_length=1, max_length=500)
    expires_at: datetime | None = None


class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    text: str
    created_at: datetime
    expires_at: datetime | None


# ---------------------------------------------------------------------------
# Tasks
# ---------------------------------------------------------------------------
@router.get("/tasks", response_model=list[TaskOut])
def list_tasks(db: Session = Depends(get_db)):
    stmt = select(Task).order_by(Task.is_complete, Task.created_at.desc())
    return db.scalars(stmt).all()


@router.post("/tasks", response_model=TaskOut, status_code=201)
def create_task(payload: TaskIn, db: Session = Depends(get_db)):
    if payload.assigned_person_id is not None and not db.get(Person, payload.assigned_person_id):
        raise HTTPException(404, "Person not found")
    task = Task(**payload.model_dump())
    db.add(task)
    db.commit()
    db.refresh(task)
    return task


@router.patch("/tasks/{task_id}", response_model=TaskOut)
def update_task(task_id: int, payload: TaskUpdate, db: Session = Depends(get_db)):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    updates = payload.model_dump(exclude_unset=True)
    if "assigned_person_id" in updates and updates["assigned_person_id"] is not None:
        if not db.get(Person, updates["assigned_person_id"]):
            raise HTTPException(404, "Person not found")
    for field, value in updates.items():
        setattr(task, field, value)
    db.commit()
    db.refresh(task)
    return task


@router.delete("/tasks/{task_id}", status_code=204)
def delete_task(task_id: int, db: Session = Depends(get_db)):
    task = db.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Task not found")
    db.delete(task)
    db.commit()


# ---------------------------------------------------------------------------
# Grocery list
# ---------------------------------------------------------------------------
@router.get("/grocery", response_model=list[GroceryItemOut])
def list_grocery_items(db: Session = Depends(get_db)):
    stmt = select(GroceryItem).order_by(GroceryItem.is_complete, GroceryItem.created_at.desc())
    return db.scalars(stmt).all()


@router.post("/grocery", response_model=GroceryItemOut, status_code=201)
def create_grocery_item(payload: GroceryItemIn, db: Session = Depends(get_db)):
    item = GroceryItem(**payload.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@router.patch("/grocery/{item_id}", response_model=GroceryItemOut)
def update_grocery_item(item_id: int, payload: GroceryItemUpdate, db: Session = Depends(get_db)):
    item = db.get(GroceryItem, item_id)
    if not item:
        raise HTTPException(404, "Grocery item not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(item, field, value)
    db.commit()
    db.refresh(item)
    return item


@router.delete("/grocery/{item_id}", status_code=204)
def delete_grocery_item(item_id: int, db: Session = Depends(get_db)):
    item = db.get(GroceryItem, item_id)
    if not item:
        raise HTTPException(404, "Grocery item not found")
    db.delete(item)
    db.commit()


# ---------------------------------------------------------------------------
# Messages
# ---------------------------------------------------------------------------
@router.get("/messages", response_model=list[MessageOut])
def list_messages(db: Session = Depends(get_db)):
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    stmt = (
        select(Message)
        .where(or_(Message.expires_at.is_(None), Message.expires_at > now))
        .order_by(Message.created_at.desc())
        .limit(20)
    )
    return db.scalars(stmt).all()


@router.post("/messages", response_model=MessageOut, status_code=201)
def create_message(payload: MessageIn, db: Session = Depends(get_db)):
    message = Message(**payload.model_dump())
    db.add(message)
    db.commit()
    db.refresh(message)
    return message


@router.delete("/messages/{message_id}", status_code=204)
def delete_message(message_id: int, db: Session = Depends(get_db)):
    message = db.get(Message, message_id)
    if not message:
        raise HTTPException(404, "Message not found")
    db.delete(message)
    db.commit()

import { useEffect, useState } from "react";
import { api, photoOriginalUrl } from "../api/client";
import type { AdguardStatus, PlazaBackground } from "../api/types";
import type { Route } from "../lib/router";
import { CasitaCard } from "./CasitaCard";
import { GroceryCard } from "./GroceryCard";
import { MessagesCard } from "./MessagesCard";
import { PhotoOverviewCard } from "./PhotoOverviewCard";
import { SecretCasitaTrigger } from "./SecretCasitaTrigger";
import { TasksOverviewCard } from "./TasksOverviewCard";

interface CasitaGridProps {
  adguardStatus: AdguardStatus | null;
  navigate: (path: Route) => void;
}

function AdguardSubtitle({ status }: { status: AdguardStatus | null }) {
  if (!status || !status.configured) {
    return <span className="casita-card__subtitle">Not connected yet</span>;
  }
  if (status.online) {
    return (
      <span className="casita-card__subtitle">
        <span className="status-dot status-dot--ok" />
        Protected
      </span>
    );
  }
  return (
    <span className="casita-card__subtitle">
      <span className="status-dot status-dot--down" />
      Offline
    </span>
  );
}

function plazaBackgroundStyle(bg: PlazaBackground | null): React.CSSProperties {
  if (!bg || bg.type === "default") return {};
  if (bg.type === "color" && bg.color) return { background: bg.color };
  if (bg.type === "image" && bg.image_filename) {
    return {
      backgroundImage: `url(${photoOriginalUrl(bg.image_filename)})`,
      backgroundSize: "cover",
      backgroundPosition: "center",
    };
  }
  return {};
}

export function CasitaGrid({ adguardStatus, navigate }: CasitaGridProps) {
  const [background, setBackground] = useState<PlazaBackground | null>(null);

  useEffect(() => {
    api.getPlazaBackground().then(setBackground).catch(() => undefined);
  }, []);

  return (
    <section className="card plaza" aria-label="More around the plaza" style={plazaBackgroundStyle(background)}>
      <div className="plaza__header">
        <h2 className="plaza__title">🌺 La Plaza</h2>
      </div>
      <div className="casita-grid">
        <PhotoOverviewCard navigate={navigate} />

        <CasitaCard title="AdGuard" wallColor="var(--color-azure)">
          <AdguardSubtitle status={adguardStatus} />
        </CasitaCard>

        <GroceryCard />
        <MessagesCard />
        <TasksOverviewCard navigate={navigate} />
        <SecretCasitaTrigger navigate={navigate} />
      </div>
    </section>
  );
}

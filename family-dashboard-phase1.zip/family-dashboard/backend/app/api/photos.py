"""
Photo Casita: upload, list, caption/album edits, delete, and albums.

Slideshow playback itself is entirely a frontend concern (see
components/SlideshowOverlay.tsx) -- this router just serves metadata; the
actual image bytes are served as static files (see main.py's /media mount
in dev, nginx in production) rather than proxied through these endpoints.
"""
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.photos import Album, Photo
from app.services import photo_service

router = APIRouter(tags=["photos"])

MAX_UPLOAD_BYTES = 15 * 1024 * 1024  # 15MB per file -- generous for a phone photo, not for video


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------
class PhotoOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    filename: str
    thumbnail_filename: str
    caption: str | None
    album_id: int | None
    sort_order: int


class PhotoUpdate(BaseModel):
    caption: str | None = None
    album_id: int | None = None
    sort_order: int | None = None


class AlbumIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)


class AlbumOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str


# ---------------------------------------------------------------------------
# Photos
# ---------------------------------------------------------------------------
@router.get("/photos", response_model=list[PhotoOut])
def list_photos(album_id: int | None = None, db: Session = Depends(get_db)):
    stmt = select(Photo)
    if album_id is not None:
        stmt = stmt.where(Photo.album_id == album_id)
    stmt = stmt.order_by(Photo.sort_order, Photo.uploaded_at.desc())
    return db.scalars(stmt).all()


@router.post("/photos", response_model=list[PhotoOut], status_code=201)
async def upload_photos(
    files: list[UploadFile] = File(...),
    album_id: int | None = Form(None),
    db: Session = Depends(get_db),
):
    if album_id is not None and not db.get(Album, album_id):
        raise HTTPException(404, "Album not found")

    created: list[Photo] = []
    errors: list[str] = []
    for upload in files:
        contents = await upload.read()
        if len(contents) > MAX_UPLOAD_BYTES:
            errors.append(f"{upload.filename}: too large (max 15MB)")
            continue
        try:
            filename, thumbnail_filename = photo_service.save_upload(contents, upload.content_type)
        except photo_service.UnsupportedImageError as exc:
            errors.append(f"{upload.filename}: {exc}")
            continue
        photo = Photo(filename=filename, thumbnail_filename=thumbnail_filename, album_id=album_id)
        db.add(photo)
        created.append(photo)

    if created:
        db.commit()
        for photo in created:
            db.refresh(photo)

    if not created and errors:
        raise HTTPException(400, "; ".join(errors))

    return created


@router.patch("/photos/{photo_id}", response_model=PhotoOut)
def update_photo(photo_id: int, payload: PhotoUpdate, db: Session = Depends(get_db)):
    photo = db.get(Photo, photo_id)
    if not photo:
        raise HTTPException(404, "Photo not found")
    updates = payload.model_dump(exclude_unset=True)
    if "album_id" in updates and updates["album_id"] is not None and not db.get(Album, updates["album_id"]):
        raise HTTPException(404, "Album not found")
    for field, value in updates.items():
        setattr(photo, field, value)
    db.commit()
    db.refresh(photo)
    return photo


@router.delete("/photos/{photo_id}", status_code=204)
def delete_photo(photo_id: int, db: Session = Depends(get_db)):
    photo = db.get(Photo, photo_id)
    if not photo:
        raise HTTPException(404, "Photo not found")
    photo_service.delete_files(photo.filename, photo.thumbnail_filename)
    db.delete(photo)
    db.commit()


# ---------------------------------------------------------------------------
# Albums
# ---------------------------------------------------------------------------
@router.get("/albums", response_model=list[AlbumOut])
def list_albums(db: Session = Depends(get_db)):
    return db.scalars(select(Album).order_by(Album.name)).all()


@router.post("/albums", response_model=AlbumOut, status_code=201)
def create_album(payload: AlbumIn, db: Session = Depends(get_db)):
    album = Album(name=payload.name)
    db.add(album)
    db.commit()
    db.refresh(album)
    return album


@router.delete("/albums/{album_id}", status_code=204)
def delete_album(album_id: int, db: Session = Depends(get_db)):
    album = db.get(Album, album_id)
    if not album:
        raise HTTPException(404, "Album not found")
    db.delete(album)  # photos in this album fall back to album_id=None (FK ondelete SET NULL)
    db.commit()

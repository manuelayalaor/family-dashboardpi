import type { Person } from "../api/types";

interface HouseRowProps {
  people: Person[];
  selectedPersonId: number | null;
  onSelect: (personId: number | null) => void;
}

export function HouseRow({ people, selectedPersonId, onSelect }: HouseRowProps) {
  return (
    <section className="card house-row" aria-label="Family houses">
      <h2 className="house-row__title">The Neighborhood</h2>
      {people.length === 0 ? (
        <p className="empty-state">No houses yet — add your family in Admin.</p>
      ) : (
        <>
          <div className="house-row__street">
            {people.map((person) => {
              const isSelected = selectedPersonId === person.id;
              return (
                <button
                  key={person.id}
                  type="button"
                  className="house"
                  aria-pressed={isSelected}
                  onClick={() => onSelect(isSelected ? null : person.id)}
                >
                  <span className="house__building">
                    <span className="house__badge" aria-hidden>
                      {person.emoji}
                    </span>
                    <span className="house__cornice" />
                    <span className="house__wall" style={{ background: person.house_color }}>
                      <span className="house__balcony-rail" />
                      <span className="house__windows">
                        <span className="house__shutter-window">
                          <span className="house__shutter" />
                          <span className="house__glass" />
                          <span className="house__shutter" />
                        </span>
                        <span className="house__shutter-window">
                          <span className="house__shutter" />
                          <span className="house__glass" />
                          <span className="house__shutter" />
                        </span>
                      </span>
                      <span className="house__door">
                        <span className="house__door-inner" />
                      </span>
                    </span>
                  </span>
                  <span className="house__name">{person.name}</span>
                </button>
              );
            })}
          </div>
          <div className="house-row__ground" aria-hidden="true" />
        </>
      )}
    </section>
  );
}

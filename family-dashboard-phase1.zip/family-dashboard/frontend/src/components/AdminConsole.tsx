import { useEffect, useRef, useState } from "react";
import { api } from "../api/client";
import type { Person } from "../api/types";
import type { Route } from "../lib/router";

interface AdminConsoleProps {
  navigate: (path: Route) => void;
}

const STARTER_COLORS = ["#E8A63D", "#3AAFA9", "#D9748C", "#1C7293", "#C1522A", "#8C6BB1"];

export function AdminConsole({ navigate }: AdminConsoleProps) {
  const [people, setPeople] = useState<Person[]>([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState("");
  const [newEmoji, setNewEmoji] = useState("🙂");
  const [submitting, setSubmitting] = useState(false);
  const colorDebounce = useRef<Record<number, number>>({});

  useEffect(() => {
    api
      .getPeople()
      .then(setPeople)
      .finally(() => setLoading(false));
  }, []);

  async function handleAddPerson(e: React.FormEvent) {
    e.preventDefault();
    const name = newName.trim();
    if (!name || submitting) return;
    setSubmitting(true);
    try {
      const color = STARTER_COLORS[people.length % STARTER_COLORS.length];
      const person = await api.createPerson({ name, emoji: newEmoji || "🙂", house_color: color });
      setPeople((prev) => [...prev, person]);
      setNewName("");
      setNewEmoji("🙂");
    } finally {
      setSubmitting(false);
    }
  }

  function updateLocal(id: number, patch: Partial<Person>) {
    setPeople((prev) => prev.map((p) => (p.id === id ? { ...p, ...patch } : p)));
  }

  async function commitField(id: number, patch: Partial<Person>) {
    await api.updatePerson(id, patch);
  }

  function handleColorChange(id: number, color: string) {
    updateLocal(id, { house_color: color });
    window.clearTimeout(colorDebounce.current[id]);
    colorDebounce.current[id] = window.setTimeout(() => commitField(id, { house_color: color }), 400);
  }

  async function handleDelete(id: number) {
    if (!window.confirm("Remove this house? Their events will be kept but unassigned.")) return;
    setPeople((prev) => prev.filter((p) => p.id !== id));
    await api.deletePerson(id);
  }

  return (
    <div className="admin">
      <section className="card admin__section">
        <h2 className="admin__section-title">People &amp; Houses</h2>
        <p className="admin__section-hint">
          Each person here gets a casita in the neighborhood. Changes save automatically.
        </p>

        {loading ? (
          <p className="empty-state">Loading…</p>
        ) : (
          <ul className="admin__people-list">
            {people.map((person) => (
              <li key={person.id} className="admin__person-row">
                <input
                  type="color"
                  className="admin__color-input"
                  value={person.house_color}
                  onChange={(e) => handleColorChange(person.id, e.target.value)}
                  aria-label={`${person.name}'s house color`}
                />
                <input
                  type="text"
                  className="widget-add__input admin__emoji-input"
                  defaultValue={person.emoji}
                  maxLength={8}
                  aria-label={`${person.name}'s emoji`}
                  onBlur={(e) => {
                    const emoji = e.target.value.trim() || "🙂";
                    updateLocal(person.id, { emoji });
                    commitField(person.id, { emoji });
                  }}
                />
                <input
                  type="text"
                  className="widget-add__input"
                  defaultValue={person.name}
                  maxLength={64}
                  aria-label="Name"
                  onBlur={(e) => {
                    const name = e.target.value.trim();
                    if (!name) return;
                    updateLocal(person.id, { name });
                    commitField(person.id, { name });
                  }}
                />
                <button
                  type="button"
                  className="widget-row__delete"
                  aria-label={`Remove ${person.name}`}
                  onClick={() => handleDelete(person.id)}
                >
                  ✕
                </button>
              </li>
            ))}
          </ul>
        )}

        <form className="widget-add" onSubmit={handleAddPerson}>
          <input
            type="text"
            className="widget-add__input admin__emoji-input"
            value={newEmoji}
            maxLength={8}
            aria-label="New person's emoji"
            onChange={(e) => setNewEmoji(e.target.value)}
          />
          <input
            type="text"
            className="widget-add__input"
            placeholder="Add a family member…"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            maxLength={64}
          />
          <button type="submit" className="widget-add__button" disabled={!newName.trim() || submitting}>
            Add House
          </button>
        </form>
      </section>

      <section className="card admin__section">
        <h2 className="admin__section-title">Calendar</h2>
        <p className="admin__section-hint">
          Events are added, edited, and deleted from the full calendar view itself.
        </p>
        <button type="button" className="widget-add__button" onClick={() => navigate("/calendar")}>
          Open Calendar →
        </button>
      </section>

      <section className="card admin__section">
        <h2 className="admin__section-title">Tasks, Grocery &amp; Messages</h2>
        <p className="admin__section-hint">
          These are managed directly in La Plaza on the home screen — add, check off, and delete right
          from the widgets there.
        </p>
        <button type="button" className="widget-add__button" onClick={() => navigate("/")}>
          Go to La Plaza →
        </button>
      </section>

      <section className="card admin__section admin__section--muted">
        <h2 className="admin__section-title">Coming later</h2>
        <p className="admin__section-hint">
          The Secret Casita PIN (Phase 5), AdGuard connection details (Phase 6), and
          display/kiosk settings (Phase 7) will get their own admin sections as those phases land.
        </p>
      </section>
    </div>
  );
}
